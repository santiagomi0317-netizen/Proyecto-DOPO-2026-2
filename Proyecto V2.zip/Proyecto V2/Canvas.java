import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.*;
import javax.swing.Timer;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * Canvas is a class to allow for simple graphical drawing on a canvas.
 * This is a modification of the general purpose Canvas, specially made for
 * the BlueJ "shapes" example. 
 *
 * @author: Bruce Quig
 * @author: Michael Kolling (mik)
 *
 * @version: 1.6 (shapes)
 */
public class Canvas{
    // Note: The implementation of this class (specifically the handling of
    // shape identity and colors) is slightly more complex than necessary. This
    // is done on purpose to keep the interface and instance fields of the
    // shape objects in this project clean and simple for educational purposes.

    private static Canvas canvasSingleton;

    /**
     * Factory method to get the canvas singleton object.
     */
    public static Canvas getCanvas(){
        if(canvasSingleton == null) {
            canvasSingleton = new Canvas("BlueJ Shapes Demo", 3000, 3000, 
                                         Color.white);
        }
        canvasSingleton.setVisible(true);
        return canvasSingleton;
    }

    //  ----- instance part -----

    private JFrame frame;
    private CanvasPane canvas;
    private Graphics2D graphic;
    private Color backgroundColour;
    private Image canvasImage;
    private List <Object> objects;
    private HashMap <Object,ShapeDescription> shapes;
    
    /**
     * Create a Canvas.
     * @param title  title to appear in Canvas Frame
     * @param width  the desired width for the canvas
     * @param height  the desired height for the canvas
     * @param bgClour  the desired background colour of the canvas
     */
    private Canvas(String title, int width, int height, Color bgColour){
        frame = new JFrame();
        canvas = new CanvasPane();
        frame.setContentPane(canvas);
        frame.setTitle(title);
        canvas.setPreferredSize(new Dimension(width, height));
        backgroundColour = bgColour;
        frame.pack();
        objects = new ArrayList <Object>();
        shapes = new HashMap <Object,ShapeDescription>();
    }

    /**
     * Set the canvas visibility and brings canvas to the front of screen
     * when made visible. This method can also be used to bring an already
     * visible canvas to the front of other windows.
     * @param visible  boolean value representing the desired visibility of
     * the canvas (true or false) 
     */
    public void setVisible(boolean visible){
        if(graphic == null) {
            // first time: instantiate the offscreen image and fill it with
            // the background colour
            Dimension size = canvas.getSize();
            canvasImage = canvas.createImage(size.width, size.height);
            graphic = (Graphics2D)canvasImage.getGraphics();
            graphic.setColor(backgroundColour);
            graphic.fillRect(0, 0, size.width, size.height);
            graphic.setColor(Color.black);
        }
        frame.setVisible(visible);
    }

    /**
     * Draw a given shape onto the canvas.
     * @param  referenceObject  an object to define identity for this shape
     * @param  color            the color of the shape
     * @param  shape            the shape object to be drawn on the canvas
     */
     // Note: this is a slightly backwards way of maintaining the shape
     // objects. It is carefully designed to keep the visible shape interfaces
     // in this project clean and simple for educational purposes.
    public void draw(Object referenceObject, String color, Shape shape){
        objects.remove(referenceObject);   // just in case it was already there
        objects.add(referenceObject);      // add at the end
        shapes.put(referenceObject, new ShapeDescription(shape, color));
        redraw();
    }
 
    /**
     * Erase a given shape's from the screen.
     * @param  referenceObject  the shape object to be erased 
     */
    public void erase(Object referenceObject){
        objects.remove(referenceObject);   // just in case it was already there
        shapes.remove(referenceObject);
        redraw();
    }

    /**
     * Set the foreground colour of the Canvas using standard CSS color strings.
     * Supports standard CSS color names and hexadecimal strings (e.g. "#FF0000").
     * Tomado de Gemini
     * 
     * @param colorString the CSS color name or hex code
     */
    public void setForegroundColor(String colorString) {
        String colorNormalized = colorString.trim().toLowerCase();

        if (colorNormalized.startsWith("#")) {
            try {
                graphic.setColor(Color.decode(colorNormalized));
                return;
            } catch (NumberFormatException e) {
                graphic.setColor(Color.black);
                return;
            }
        }

        switch (colorNormalized) {
            //case "aliceblue": graphic.setColor(new Color(240, 248, 255)); break;
            //case "antiquewhite": graphic.setColor(new Color(250, 235, 215)); break;
            //case "aqua":
            case "cyan": graphic.setColor(Color.cyan); break;
            case "aquamarine": graphic.setColor(new Color(127, 255, 212)); break;
            //case "azure": graphic.setColor(new Color(240, 255, 255)); break;
            //case "beige": graphic.setColor(new Color(245, 245, 220)); break;
            case "bisque": graphic.setColor(new Color(255, 228, 196)); break;
            case "black": graphic.setColor(Color.black); break;
            //case "blanchedalmond": graphic.setColor(new Color(255, 235, 205)); break;
            case "blue": graphic.setColor(Color.blue); break;
            case "blueviolet": graphic.setColor(new Color(138, 43, 226)); break;
            case "brown": graphic.setColor(new Color(165, 42, 42)); break;
            case "burlywood": graphic.setColor(new Color(222, 184, 135)); break;
            case "cadetblue": graphic.setColor(new Color(95, 158, 160)); break;
            case "chartreuse": graphic.setColor(new Color(127, 255, 0)); break;
            case "chocolate": graphic.setColor(new Color(210, 105, 30)); break;
            case "coral": graphic.setColor(new Color(255, 127, 80)); break;
            case "cornflowerblue": graphic.setColor(new Color(100, 149, 237)); break;
            //case "cornsilk": graphic.setColor(new Color(255, 248, 220)); break;
            case "crimson": graphic.setColor(new Color(220, 20, 60)); break;
            case "darkblue": graphic.setColor(new Color(0, 0, 139)); break;
            case "darkcyan": graphic.setColor(new Color(0, 139, 139)); break;
            case "darkgoldenrod": graphic.setColor(new Color(184, 134, 11)); break;
            //case "darkgray":
            case "darkgrey": graphic.setColor(Color.darkGray); break;
            case "darkgreen": graphic.setColor(new Color(0, 100, 0)); break;
            case "darkkhaki": graphic.setColor(new Color(189, 183, 107)); break;
            case "darkmagenta": graphic.setColor(new Color(139, 0, 139)); break;
            case "darkolivegreen": graphic.setColor(new Color(85, 107, 47)); break;
            case "darkorange": graphic.setColor(new Color(255, 140, 0)); break;
            case "darkorchid": graphic.setColor(new Color(153, 50, 204)); break;
            case "darkred": graphic.setColor(new Color(139, 0, 0)); break;
            case "darksalmon": graphic.setColor(new Color(233, 150, 122)); break;
            case "darkseagreen": graphic.setColor(new Color(143, 188, 143)); break;
            case "darkslateblue": graphic.setColor(new Color(72, 61, 139)); break;
            //case "darkslategray":
            case "darkslategrey": graphic.setColor(new Color(47, 79, 79)); break;
            case "darkturquoise": graphic.setColor(new Color(0, 206, 209)); break;
            case "darkviolet": graphic.setColor(new Color(148, 0, 211)); break;
            case "deeppink": graphic.setColor(new Color(255, 20, 147)); break;
            case "deepskyblue": graphic.setColor(new Color(0, 191, 255)); break;
            //case "dimgray":
            case "dimgrey": graphic.setColor(new Color(105, 105, 105)); break;
            case "dodgerblue": graphic.setColor(new Color(30, 144, 255)); break;
            case "firebrick": graphic.setColor(new Color(178, 34, 34)); break;
            //case "floralwhite": graphic.setColor(new Color(255, 250, 240)); break;
            case "forestgreen": graphic.setColor(new Color(34, 139, 34)); break;
            case "fuchsia":
            case "magenta": graphic.setColor(Color.magenta); break;
            case "gainsboro": graphic.setColor(new Color(220, 220, 220)); break;
            //case "ghostwhite": graphic.setColor(new Color(248, 248, 255)); break;
            case "gold": graphic.setColor(new Color(255, 215, 0)); break;
            case "goldenrod": graphic.setColor(new Color(218, 165, 32)); break;
            //case "gray":
            case "grey": graphic.setColor(Color.gray); break;
            case "green": graphic.setColor(Color.green); break;
            case "greenyellow": graphic.setColor(new Color(173, 255, 47)); break;
            //case "honeydew": graphic.setColor(new Color(240, 255, 240)); break;
            case "hotpink": graphic.setColor(new Color(255, 105, 180)); break;
            case "indianred": graphic.setColor(new Color(205, 92, 92)); break;
            case "indigo": graphic.setColor(new Color(75, 0, 130)); break;
            //case "ivory": graphic.setColor(new Color(255, 255, 240)); break;
            case "khaki": graphic.setColor(new Color(240, 230, 140)); break;
            //case "lavender": graphic.setColor(new Color(230, 230, 250)); break;
            //case "lavenderblush": graphic.setColor(new Color(255, 240, 245)); break;
            case "lawngreen": graphic.setColor(new Color(124, 252, 0)); break;
            //case "lemonchiffon": graphic.setColor(new Color(255, 250, 205)); break;
            case "lightblue": graphic.setColor(new Color(173, 216, 230)); break;
            case "lightcoral": graphic.setColor(new Color(240, 128, 128)); break;
            //case "lightcyan": graphic.setColor(new Color(224, 255, 255)); break;
            //case "lightgoldenrodyellow": graphic.setColor(new Color(250, 250, 210)); break;
            //case "lightgray":
            case "lightgrey": graphic.setColor(Color.lightGray); break;
            case "lightgreen": graphic.setColor(new Color(144, 238, 144)); break;
            case "lightpink": graphic.setColor(new Color(255, 182, 193)); break;
            case "lightsalmon": graphic.setColor(new Color(255, 160, 122)); break;
            case "lightseagreen": graphic.setColor(new Color(32, 178, 170)); break;
            case "lightskyblue": graphic.setColor(new Color(135, 206, 250)); break;
            //case "lightslategray":
            case "lightslategrey": graphic.setColor(new Color(119, 136, 153)); break;
            case "lightsteelblue": graphic.setColor(new Color(176, 196, 222)); break;
            //case "lightyellow": graphic.setColor(new Color(255, 255, 224)); break;
            case "lime": graphic.setColor(new Color(0, 255, 0)); break;
            case "limegreen": graphic.setColor(new Color(50, 205, 50)); break;
            //case "linen": graphic.setColor(new Color(250, 240, 230)); break;
            case "maroon": graphic.setColor(new Color(128, 0, 0)); break;
            case "mediumaquamarine": graphic.setColor(new Color(102, 205, 170)); break;
            case "mediumblue": graphic.setColor(new Color(0, 0, 205)); break;
            case "mediumorchid": graphic.setColor(new Color(186, 85, 211)); break;
            case "mediumpurple": graphic.setColor(new Color(147, 112, 219)); break;
            case "mediumseagreen": graphic.setColor(new Color(60, 179, 113)); break;
            case "mediumslateblue": graphic.setColor(new Color(123, 104, 238)); break;
            case "mediumspringgreen": graphic.setColor(new Color(0, 250, 154)); break;
            case "mediumturquoise": graphic.setColor(new Color(72, 209, 204)); break;
            case "mediumvioletred": graphic.setColor(new Color(199, 21, 133)); break;
            case "midnightblue": graphic.setColor(new Color(25, 25, 112)); break;
            //case "mintcream": graphic.setColor(new Color(245, 255, 250)); break;
            case "mistyrose": graphic.setColor(new Color(255, 228, 225)); break;
            case "moccasin": graphic.setColor(new Color(255, 228, 181)); break;
            case "navajowhite": graphic.setColor(new Color(255, 222, 173)); break;
            case "navy": graphic.setColor(new Color(0, 0, 128)); break;
            //case "oldlace": graphic.setColor(new Color(253, 245, 230)); break;
            case "olive": graphic.setColor(new Color(128, 128, 0)); break;
            case "olivedrab": graphic.setColor(new Color(107, 142, 35)); break;
            case "orange": graphic.setColor(Color.orange); break;
            case "orangered": graphic.setColor(new Color(255, 69, 0)); break;
            case "orchid": graphic.setColor(new Color(218, 112, 214)); break;
            case "palegoldenrod": graphic.setColor(new Color(238, 232, 170)); break;
            case "palegreen": graphic.setColor(new Color(152, 251, 152)); break;
            case "paleturquoise": graphic.setColor(new Color(175, 238, 238)); break;
            case "palevioletred": graphic.setColor(new Color(219, 112, 147)); break;
            //case "papayawhip": graphic.setColor(new Color(255, 239, 213)); break;
            case "peachpuff": graphic.setColor(new Color(255, 218, 185)); break;
            case "peru": graphic.setColor(new Color(205, 133, 63)); break;
            case "pink": graphic.setColor(Color.pink); break;
            case "plum": graphic.setColor(new Color(221, 160, 221)); break;
            case "powderblue": graphic.setColor(new Color(176, 224, 230)); break;
            case "purple": graphic.setColor(new Color(128, 0, 128)); break;
            case "rebeccapurple": graphic.setColor(new Color(102, 51, 153)); break;
            case "red": graphic.setColor(Color.red); break;
            case "rosybrown": graphic.setColor(new Color(188, 143, 143)); break;
            case "royalblue": graphic.setColor(new Color(65, 105, 225)); break;
            case "saddlebrown": graphic.setColor(new Color(139, 69, 19)); break;
            case "salmon": graphic.setColor(new Color(250, 128, 114)); break;
            case "sandybrown": graphic.setColor(new Color(244, 164, 96)); break;
            case "seagreen": graphic.setColor(new Color(46, 139, 87)); break;
            //case "seashell": graphic.setColor(new Color(255, 245, 238)); break;
            case "sienna": graphic.setColor(new Color(160, 82, 45)); break;
            case "silver": graphic.setColor(new Color(192, 192, 192)); break;
            case "skyblue": graphic.setColor(new Color(135, 206, 235)); break;
            case "slateblue": graphic.setColor(new Color(106, 90, 205)); break;
            //case "slategray":
            case "slategrey": graphic.setColor(new Color(112, 128, 144)); break;
            //case "snow": graphic.setColor(new Color(255, 250, 250)); break;
            case "springgreen": graphic.setColor(new Color(0, 255, 127)); break;
            case "steelblue": graphic.setColor(new Color(70, 130, 180)); break;
            case "tan": graphic.setColor(new Color(210, 180, 140)); break;
            case "teal": graphic.setColor(new Color(0, 128, 128)); break;
            case "thistle": graphic.setColor(new Color(216, 191, 216)); break;
            case "tomato": graphic.setColor(new Color(255, 99, 71)); break;
            case "turquoise": graphic.setColor(new Color(64, 224, 208)); break;
            case "violet": graphic.setColor(new Color(238, 130, 238)); break;
            case "wheat": graphic.setColor(new Color(245, 222, 179)); break;
            //case "white": graphic.setColor(Color.white); break;
            //case "whitesmoke": graphic.setColor(new Color(245, 245, 245)); break;
            case "yellow": graphic.setColor(Color.yellow); break;
            case "yellowgreen": graphic.setColor(new Color(154, 205, 50)); break;
            default: graphic.setColor(Color.black); break;
        }
    }

    /**
     * Wait for a specified number of milliseconds before finishing.
     * This provides an easy way to specify a small delay which can be
     * used when producing animations.
     * @param  milliseconds  the number 
     */
    public void wait(int milliseconds){
        try{
            Thread.sleep(milliseconds);
        } catch (Exception e){
            // ignoring exception at the moment
        }
    }

    /**
     * Redraw ell shapes currently on the Canvas.
     */
    private void redraw(){
        erase();
        for(Iterator i=objects.iterator(); i.hasNext(); ) {
                       shapes.get(i.next()).draw(graphic);
        }
        canvas.repaint();
    }
       
    /**
     * Erase the whole canvas. (Does not repaint.)
     */
    private void erase(){
        Color original = graphic.getColor();
        graphic.setColor(backgroundColour);
        Dimension size = canvas.getSize();
        graphic.fill(new java.awt.Rectangle(0, 0, size.width, size.height));
        graphic.setColor(original);
    }


    /************************************************************************
     * Inner class CanvasPane - the actual canvas component contained in the
     * Canvas frame. This is essentially a JPanel with added capability to
     * refresh the image drawn on it.
     */
    private class CanvasPane extends JPanel{
        public void paint(Graphics g){
            g.drawImage(canvasImage, 0, 0, null);
        }
    }
    
    /************************************************************************
     * Inner class CanvasPane - the actual canvas component contained in the
     * Canvas frame. This is essentially a JPanel with added capability to
     * refresh the image drawn on it.
     */
    private class ShapeDescription{
        private Shape shape;
        private String colorString;

        public ShapeDescription(Shape shape, String color){
            this.shape = shape;
            colorString = color;
        }

        public void draw(Graphics2D graphic){
            setForegroundColor(colorString);
            graphic.draw(shape);
            graphic.fill(shape);
        }
    }
    
    /**
     * Dibuja una cadena de texto directamente en el Canvas.
     * Tomado de gemini
     */
    public void drawString(String text, int x, int y, String color, int fontSize) {
    setForegroundColor(color);
    graphic.setFont(new Font("SansSerif", Font.BOLD, fontSize));
    graphic.drawString(text, x, y);
    canvas.repaint();
    }   
    
    /**
     * Borra una cadena de texto en las coordenadas dadas redibujándola en blanco.
     * Tomado de gemini
     */
    public void eraseString(String text, int x, int y) {
        setForegroundColor("white");
        graphic.drawString(text, x, y);
        canvas.repaint();
    }
    
    /**
     * Muestra un mensaje flotante en el Canvas durante un número especificado de milisegundos.
     * @param text Mensaje a mostrar
     * @param x Coordenada X
     * @param y Coordenada Y
     * @param color Color del texto
     * @param delayMs Tiempo de permanencia en milisegundos (ej. 3000 ms = 3 segundos)
     * Tomado de gemini
     */
    public void showFloatingMessage(String text, int x, int y, String color, int fontSize, int delayMs) {
        drawString(text, x, y, color, fontSize);
    
        Timer timer = new Timer(delayMs, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eraseString(text, x, y);
                ((Timer) e.getSource()).stop(); // Detener el temporizador tras borrarse
            }
        });
        
        timer.setRepeats(false); // Ejecutar solo una vez
        timer.start();
    }
    
}
    
