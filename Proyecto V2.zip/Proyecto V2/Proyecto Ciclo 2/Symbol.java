import javax.swing.JOptionPane;
import java.util.Random;
/**
 * Write a description of class Symbol here.
 * 
 * @author (Santiago Murillo) 
 * @version (9 de septiembre)
 */
public class Symbol{
    private String color;
    private String forma;
    private boolean isVisible;
    private Circle circulo;
    private Rectangle rectangulo;
    private Triangle triangulo;
    public static String[] figuras = {"triangle","circle","rectangle"};
    
    /**
     * Constructor para instanciar un nuevo Symbol.
     * 
     * @param color identificador del color (ej. "red", "blue", "yellow")
     * @param forma tipo de figura geométrica ("Triangle", "Circle", "Rectangle")
     */
    public Symbol(String color, String forma) {
        String cssColor = validColor(color);
        if (cssColor != null){
            this.color = cssColor;
            if (forma != null && !forma.trim().isEmpty()) {
                this.forma = forma.trim().toLowerCase();
            } else {
                Random random = new Random();
                int randomIndex = random.nextInt(figuras.length);
                this.forma = figuras[randomIndex];
            }
            this.isVisible = false;
            createFigure(this.color, this.forma);
        } else {
            JOptionPane.showMessageDialog(null, "Color no válido según el estándar CSS", "Error", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    /**
     * Obtiene el color identificador del símbolo.
     * 
     * @return el nombre o código del color
     */
    public String getColor() {
        return this.color;
    }
    
    /**
     * Obtiene el tipo de forma geométrica del símbolo.
     * 
     * @return el nombre de la figura geométrica
     */
    public String getForm() {
        return this.forma;
    }
    
    /**
     * Oculta la figura del símbolo de la pantalla.
     */
    public void makeInvisible() {
        this.isVisible = false;
        if (circulo != null) circulo.makeInvisible();
        if (rectangulo != null) rectangulo.makeInvisible();
        if (triangulo != null) triangulo.makeInvisible();
    }
    
    /**
     * Muestra la figura del símbolo de la pantalla.
     * 
     * @return true si es visible, false en caso contrario
     */
    public void makeVisible() {
        this.isVisible = true;
        if (circulo != null) circulo.makeVisible();
        if (rectangulo != null) rectangulo.makeVisible();
        if (triangulo != null) triangulo.makeVisible();
    }
    
    /**
     * Desplaza horizontalmente la figura visual para alinearla en su columna.
     * 
     * @param distance Cantidad de píxeles a desplazar.
     */
    public void moveHorizontal(int distance) {
        if (circulo != null) circulo.moveHorizontal(distance);
        if (rectangulo != null) rectangulo.moveHorizontal(distance);
        if (triangulo != null) triangulo.moveHorizontal(distance);
    }

    /**
     * Desplaza verticalmente la figura visual en la pantalla.
     * 
     * @param distance cantidad de píxeles a mover en el eje Y
     */
    public void moveVertical(int distance) {
        if (circulo != null) circulo.moveVertical(distance);
        if (rectangulo != null) rectangulo.moveVertical(distance);
        if (triangulo != null) triangulo.moveVertical(distance);
    }  
    
    /**
     * Normaliza la cadena para asegurar compatibilidad con nombres de colores estándar CSS.
     * Convierte la cadena a minúsculas y elimina espacios extras.
     * Verifica si el color dado esta en la libreria, si salta el error lo cogemos y retornamos el bull
     * @param color (String)
     */
    public static String validColor(String color) {
        if (color == null || color.trim().isEmpty()) {
            return null;
        }
        String c = color.trim().toLowerCase();
        switch (c) {
            case "red":
            case "black":
            case "blue":
            case "yellow":
            case "green":
            case "magenta":
            case "white":
            case "cyan":
            case "orange":
            case "pink":
            case "gray":
            case "grey":
            case "darkgray":
            case "lightgray":
            case "purple":
            case "brown":
                return c;
        }
        
        switch (c) {
            case "#ff0000": return "red";
            case "#000000": return "black";
            case "#0000ff": return "blue";
            case "#ffff00": return "yellow";
            case "#008000": return "green";
            case "#ff00ff": return "magenta";
            case "#ffffff": return "white";
            case "#00ffff": return "cyan";
            case "#ffa500": return "orange";
            case "#ffc0cb": return "pink";
            case "#808080": return "grey";
            case "#a9a9a9": return "darkgray";
            case "#d3d3d3": return "lightgray";
            case "#800080": return "purple"; 
            case "#a52a2a": return "brown";
        }
        return null;
    }
    
    /**
     * Crea la figura correspondiente según el valor de 'forma' y le aplica el color.
     * @param color (String)
     * @param forma (String)
     */
    private void createFigure(String color, String forma) {
        String f = forma.trim().toLowerCase();
        if (forma.equals("circle")) {
            circulo = new Circle();
            circulo.changeColor(color);
            circulo.moveHorizontal(10); 
            circulo.moveVertical(10);
        } else if (forma.equals("rectangle")) {
            rectangulo = new Rectangle();
            rectangulo.changeColor(color);
            rectangulo.moveHorizontal(10);
            rectangulo.moveVertical(10);
        } else if (forma.equals("triangle")) {
            triangulo = new Triangle();
            triangulo.changeColor(color);
            triangulo.moveHorizontal(25);
            triangulo.moveVertical(10);
        }  else {
            JOptionPane.showMessageDialog(null, "Figura no disponible", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}