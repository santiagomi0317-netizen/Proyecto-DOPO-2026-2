import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;

/**
 * Clase y Creador que contiene los colores CSS (Con su equivalencia hexadecimal) y los administra a partir de un hashmap
 * 
 * @author (Santiago Murillo) 
 * 
 * @version (12 de septiembre)
 * Lista de colores disponibles y sus códigos hexadecimales:
 * <ul>
 *   <li><b>aqua:</b> #00ffff</li>
 *   <li><b>aquamarine:</b> #7fffd4</li>
 *   <li><b>bisque:</b> #ffe4c4</li>
 *   <li><b>black:</b> #000000</li>
 *   <li><b>blue:</b> #0000ff</li>
 *   <li><b>blueviolet:</b> #8a2be2</li>
 *   <li><b>brown:</b> #a52a2a</li>
 *   <li><b>burlywood:</b> #deb887</li>
 *   <li><b>cadetblue:</b> #5f9ea0</li>
 *   <li><b>chartreuse:</b> #7fff00</li>
 *   <li><b>chocolate:</b> #d2691e</li>
 *   <li><b>coral:</b> #ff7f50</li>
 *   <li><b>cornflowerblue:</b> #6495ed</li>
 *   <li><b>crimson:</b> #dc143c</li>
 *   <li><b>darkblue:</b> #00008b</li>
 *   <li><b>darkcyan:</b> #008b8b</li>
 *   <li><b>darkgoldenrod:</b> #b8860b</li>
 *   <li><b>darkgreen:</b> #006400</li>
 *   <li><b>darkkhaki:</b> #bdb76b</li>
 *   <li><b>darkmagenta:</b> #8b008b</li>
 *   <li><b>darkolivegreen:</b> #556b2f</li>
 *   <li><b>darkorange:</b> #ff8c00</li>
 *   <li><b>darkorchid:</b> #9932cc</li>
 *   <li><b>darkred:</b> #8b0000</li>
 *   <li><b>darksalmon:</b> #e9967a</li>
 *   <li><b>darkseagreen:</b> #8fbc8f</li>
 *   <li><b>darkslateblue:</b> #483d8b</li>
 *   <li><b>darkturquoise:</b> #00ced1</li>
 *   <li><b>darkviolet:</b> #9400d3</li>
 *   <li><b>deeppink:</b> #ff1493</li>
 *   <li><b>deepskyblue:</b> #00bfff</li>
 *   <li><b>dimgray:</b> #696969</li>
 *   <li><b>dodgerblue:</b> #1e90ff</li>
 *   <li><b>firebrick:</b> #b22222</li>
 *   <li><b>forestgreen:</b> #228b22</li>
 *   <li><b>fuchsia:</b> #ff00ff</li>
 *   <li><b>gainsboro:</b> #dcdcdc</li>
 *   <li><b>gold:</b> #ffd700</li>
 *   <li><b>goldenrod:</b> #daa520</li>
 *   <li><b>gray:</b> #808080</li>
 *   <li><b>green:</b> #008000</li>
 *   <li><b>greenyellow:</b> #adff2f</li>
 *   <li><b>hotpink:</b> #ff69b4</li>
 *   <li><b>indianred:</b> #cd5c5c</li>
 *   <li><b>indigo:</b> #4b0082</li>
 *   <li><b>khaki:</b> #f0e68c</li>
 *   <li><b>lawngreen:</b> #7cfc00</li>
 *   <li><b>lightblue:</b> #add8e6</li>
 *   <li><b>lightcoral:</b> #f08080</li>
 *   <li><b>lightgray:</b> #d3d3d3</li>
 *   <li><b>lightgreen:</b> #90ee90</li>
 *   <li><b>lightpink:</b> #ffb6c1</li>
 *   <li><b>lightsalmon:</b> #ffa07a</li>
 *   <li><b>lightseagreen:</b> #20b2aa</li>
 *   <li><b>lightskyblue:</b> #87cefa</li>
 *   <li><b>lightslategray:</b> #778899</li>
 *   <li><b>lightsteelblue:</b> #b0c4de</li>
 *   <li><b>lime:</b> #00ff00</li>
 *   <li><b>limegreen:</b> #32cd32</li>
 *   <li><b>maroon:</b> #800000</li>
 *   <li><b>mediumaquamarine:</b> #66cdaa</li>
 *   <li><b>mediumblue:</b> #0000cd</li>
 *   <li><b>mediumorchid:</b> #ba55d3</li>
 *   <li><b>mediumpurple:</b> #9370db</li>
 *   <li><b>mediumseagreen:</b> #3cb371</li>
 *   <li><b>mediumslateblue:</b> #7b68ee</li>
 *   <li><b>mediumspringgreen:</b> #00fa9a</li>
 *   <li><b>mediumturquoise:</b> #48d1cc</li>
 *   <li><b>mediumvioletred:</b> #c71585</li>
 *   <li><b>midnightblue:</b> #191970</li>
 *   <li><b>mistyrose:</b> #ffe4e1</li>
 *   <li><b>moccasin:</b> #ffe4b5</li>
 *   <li><b>navajowhite:</b> #ffdead</li>
 *   <li><b>navy:</b> #000080</li>
 *   <li><b>olive:</b> #808000</li>
 *   <li><b>olivedrab:</b> #6b8e23</li>
 *   <li><b>orange:</b> #ffa500</li>
 *   <li><b>orangered:</b> #ff4500</li>
 *   <li><b>orchid:</b> #da70d6</li>
 *   <li><b>palegoldenrod:</b> #eee8aa</li>
 *   <li><b>palegreen:</b> #98fb98</li>
 *   <li><b>paleturquoise:</b> #afeeee</li>
 *   <li><b>palevioletred:</b> #db7093</li>
 *   <li><b>peachpuff:</b> #ffdab9</li>
 *   <li><b>peru:</b> #cd853f</li>
 *   <li><b>pink:</b> #ffc0cb</li>
 *   <li><b>plum:</b> #dda0dd</li>
 *   <li><b>powderblue:</b> #b0e0e6</li>
 *   <li><b>purple:</b> #800080</li>
 *   <li><b>rebeccapurple:</b> #663399</li>
 *   <li><b>red:</b> #ff0000</li>
 *   <li><b>rosybrown:</b> #bc8f8f</li>
 *   <li><b>royalblue:</b> #4169e1</li>
 *   <li><b>saddlebrown:</b> #8b4513</li>
 *   <li><b>salmon:</b> #fa8072</li>
 *   <li><b>sandybrown:</b> #f4a460</li>
 *   <li><b>seagreen:</b> #2e8b57</li>
 *   <li><b>sienna:</b> #a0522d</li>
 *   <li><b>silver:</b> #c0c0c0</li>
 *   <li><b>skyblue:</b> #87ceeb</li>
 *   <li><b>slateblue:</b> #6a5acd</li>
 *   <li><b>slategray:</b> #708090</li>
 *   <li><b>springgreen:</b> #00ff7f</li>
 *   <li><b>steelblue:</b> #4682b4</li>
 *   <li><b>tan:</b> #d2b48c</li>
 *   <li><b>teal:</b> #008080</li>
 *   <li><b>thistle:</b> #d8bfd8</li>
 *   <li><b>tomato:</b> #ff6347</li>
 *   <li><b>turquoise:</b> #40e0d0</li>
 *   <li><b>violet:</b> #ee82ee</li>
 *   <li><b>wheat:</b> #f5deb3</li>
 *   <li><b>yellow:</b> #ffff00</li>
 *   <li><b>yellowgreen:</b> #9acd32</li>
 * </ul>
 */
public class validColor {
    public static Map<String, String> map = new HashMap<>();
    static {
        //map.put("#f0f8ff", "aliceblue");
        //map.put("#faebd7", "antiquewhite");
        map.put("#00ffff", "aqua");
        map.put("#7fffd4", "aquamarine");
        //map.put("#f0ffff", "azure");
        //map.put("#f5f5dc", "beige");
        map.put("#ffe4c4", "bisque");
        map.put("#000000", "black");
        //map.put("#ffebcd", "blanchedalmond");
        map.put("#0000ff", "blue");
        map.put("#8a2be2", "blueviolet");
        map.put("#a52a2a", "brown");
        map.put("#deb887", "burlywood");
        map.put("#5f9ea0", "cadetblue");
        map.put("#7fff00", "chartreuse");
        map.put("#d2691e", "chocolate");
        map.put("#ff7f50", "coral");
        map.put("#6495ed", "cornflowerblue");
        //map.put("#fff8dc", "cornsilk");
        map.put("#dc143c", "crimson");
        map.put("#00008b", "darkblue");
        map.put("#008b8b", "darkcyan");
        map.put("#b8860b", "darkgoldenrod");
        //map.put("#a9a9a9", "darkgray");
        map.put("#006400", "darkgreen");
        map.put("#bdb76b", "darkkhaki");
        map.put("#8b008b", "darkmagenta");
        map.put("#556b2f", "darkolivegreen");
        map.put("#ff8c00", "darkorange");
        map.put("#9932cc", "darkorchid");
        map.put("#8b0000", "darkred");
        map.put("#e9967a", "darksalmon");
        map.put("#8fbc8f", "darkseagreen");
        map.put("#483d8b", "darkslateblue");
        //map.put("#2f4f4f", "darkslategray");
        map.put("#00ced1", "darkturquoise");
        map.put("#9400d3", "darkviolet");
        map.put("#ff1493", "deeppink");
        map.put("#00bfff", "deepskyblue");
        map.put("#696969", "dimgray");
        map.put("#1e90ff", "dodgerblue");
        map.put("#b22222", "firebrick");
        //map.put("#fffaf0", "floralwhite");
        map.put("#228b22", "forestgreen");
        map.put("#ff00ff", "fuchsia");
        map.put("#dcdcdc", "gainsboro");
        //map.put("#f8f8ff", "ghostwhite");
        map.put("#ffd700", "gold");
        map.put("#daa520", "goldenrod");
        map.put("#808080", "gray");
        map.put("#008000", "green");
        map.put("#adff2f", "greenyellow");
        //map.put("#f0fff0", "honeydew");
        map.put("#ff69b4", "hotpink");
        map.put("#cd5c5c", "indianred");
        map.put("#4b0082", "indigo");
        //map.put("#fffff0", "ivory");
        map.put("#f0e68c", "khaki");
        //map.put("#e6e6fa", "lavender");
        //map.put("#fff0f5", "lavenderblush");
        map.put("#7cfc00", "lawngreen");
        //map.put("#fffacd", "lemonchiffon");
        map.put("#add8e6", "lightblue");
        map.put("#f08080", "lightcoral");
        //map.put("#e0ffff", "lightcyan");
        //map.put("#fafad2", "lightgoldenrodyellow");
        map.put("#d3d3d3", "lightgray");
        map.put("#90ee90", "lightgreen");
        map.put("#ffb6c1", "lightpink");
        map.put("#ffa07a", "lightsalmon");
        map.put("#20b2aa", "lightseagreen");
        map.put("#87cefa", "lightskyblue");
        map.put("#778899", "lightslategray");
        map.put("#b0c4de", "lightsteelblue");
        //map.put("#ffffe0", "lightyellow");
        map.put("#00ff00", "lime");
        map.put("#32cd32", "limegreen");
        //map.put("#faf0e6", "linen");
        map.put("#800000", "maroon");
        map.put("#66cdaa", "mediumaquamarine");
        map.put("#0000cd", "mediumblue");
        map.put("#ba55d3", "mediumorchid");
        map.put("#9370db", "mediumpurple");
        map.put("#3cb371", "mediumseagreen");
        map.put("#7b68ee", "mediumslateblue");
        map.put("#00fa9a", "mediumspringgreen");
        map.put("#48d1cc", "mediumturquoise");
        map.put("#c71585", "mediumvioletred");
        map.put("#191970", "midnightblue");
        //map.put("#f5fffa", "mintcream");
        map.put("#ffe4e1", "mistyrose");
        map.put("#ffe4b5", "moccasin");
        map.put("#ffdead", "navajowhite");
        map.put("#000080", "navy");
        //map.put("#fdf5e6", "oldlace");
        map.put("#808000", "olive");
        map.put("#6b8e23", "olivedrab");
        map.put("#ffa500", "orange");
        map.put("#ff4500", "orangered");
        map.put("#da70d6", "orchid");
        map.put("#eee8aa", "palegoldenrod");
        map.put("#98fb98", "palegreen");
        map.put("#afeeee", "paleturquoise");
        map.put("#db7093", "palevioletred");
        //map.put("#ffefd5", "papayawhip");
        map.put("#ffdab9", "peachpuff");
        map.put("#cd853f", "peru");
        map.put("#ffc0cb", "pink");
        map.put("#dda0dd", "plum");
        map.put("#b0e0e6", "powderblue");
        map.put("#800080", "purple");
        map.put("#663399", "rebeccapurple");
        map.put("#ff0000", "red");
        map.put("#bc8f8f", "rosybrown");
        map.put("#4169e1", "royalblue");
        map.put("#8b4513", "saddlebrown");
        map.put("#fa8072", "salmon");
        map.put("#f4a460", "sandybrown");
        map.put("#2e8b57", "seagreen");
        //map.put("#fff5ee", "seashell");
        map.put("#a0522d", "sienna");
        map.put("#c0c0c0", "silver");
        map.put("#87ceeb", "skyblue");
        map.put("#6a5acd", "slateblue");
        map.put("#708090", "slategray");
        //map.put("#fffafa", "snow");
        map.put("#00ff7f", "springgreen");
        map.put("#4682b4", "steelblue");
        map.put("#d2b48c", "tan");
        map.put("#008080", "teal");
        map.put("#d8bfd8", "thistle");
        map.put("#ff6347", "tomato");
        map.put("#40e0d0", "turquoise");
        map.put("#ee82ee", "violet");
        map.put("#f5deb3", "wheat");
        //map.put("#ffffff", "white");
        //map.put("#f5f5f5", "whitesmoke");
        map.put("#ffff00", "yellow");
        map.put("#9acd32", "yellowgreen");
    }
    
    /**
     * Busca un color en el hashmap, puede ser el nombre o equivalencia hexadecimal
     * @param txt (String) String que puede ser su hexadecimal o nombre del color
     * @return String, da su nombre de color si esta en el hashmap, null si no esta
     */
    // Invariante: Retorna el nombre del color correspondiente si el texto ingresado coincide con una clave hexadecimal existente en el mapa o si se encuentra registrado como un valor de nombre válido; en caso contrario, retorna null.
    public static String colorExists(String txt) {
        if (txt == null) return null;
        if (txt.startsWith("#")) {
            return getName(txt);
        } else {
            if (map.containsValue(txt)) {
                return txt;
            } else {
                return null;
            }
        }
    }
    
    /**
     * Busca en el hashmap a partir de su código hexadecimal 
     * @param hex (String) código hexadecimal
     * @return String, da su nombre de color si esta en el hashmap, null si no esta
     */
    // Invariante: Devuelve siempre el valor textual del nombre del color asociado a la clave hexadecimal consultada en el mapa estático de colores.
    public static String getName(String hex){
        return map.get(hex);
    } 
}