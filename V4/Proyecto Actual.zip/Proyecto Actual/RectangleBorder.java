/**
 * Representa un marco o rectángulo compuesto únicamente por sus bordes.
 * Permite encerrar figuras sin tapar el fondo.
 * Tomado de Gemini
 * 
 * @author Santiago Murillo
 * @version 2026-2
 */
public class RectangleBorder {
    private Rectangle up;
    private Rectangle down;
    private Rectangle left;
    private Rectangle right;
    private boolean isVisible;
    private int width;
    private int height;
    private int thickness;
    private int x;
    private int y;

    /**
     * Constructor para un rectángulo de solo bordes.
     * 
     * @param width Ancho total del marco.
     * @param height Alto total del marco.
     * @param thickness Grosor de la línea del borde.
     * @param color Color del borde (ej. "black", "red", "blue").
     */
    // Invariante: Un objeto RectangleBorder siempre se inicializa como no visible (isVisible = false) compuesto por cuatro rectángulos que representan los límites superior, inferior, izquierdo y derecho.
    public RectangleBorder(int width, int height, int thickness, String color) {
        this.width = width;
        this.height = height;
        this.thickness = thickness;
        this.isVisible = false;
        this.x = 0;
        this.y = 0;
        up = new Rectangle();
        down = new Rectangle();
        left = new Rectangle();
        right = new Rectangle();
        
        adjustRectangle();
        changeColor(color);
    }

    /**
     * Ajusta las dimensiones y posiciones de las 4 líneas para formar el borde.
     */
    // Invariante: Configura el tamaño y la posición relativa de los cuatro rectángulos perimetrales para mantener las proporciones exactas de ancho, alto y grosor especificadas.
    private void adjustRectangle() {
        // Lado up e down
        up.changeSize(thickness, width);
        down.changeSize(thickness, width);

        // Lado left y right
        left.changeSize(height, thickness);
        right.changeSize(height, thickness);

        // Posicionar lados opuestos
        down.moveVertical(height - thickness);
        right.moveHorizontal(width - thickness);
    }

    /**
     * Cambia el tamaño del marco de bordes manteniendo fija la esquina superior izquierda.
     * @param newWidth Nuevo ancho del marco.
     * @param newHeight Nuevo alto del marco.
     */
    //Tomado de Gemini
    public void changeSize(int newWidth, int newHeight) {
        boolean estabaVisible = isVisible;
        if (estabaVisible) makeInvisible();
    
        // 1. Regresar las líneas down y right a la esquina superior izquierda (origen relativo del marco)
        down.moveVertical(-(this.height - this.thickness));
        right.moveHorizontal(-(this.width - this.thickness));
    
        // 2. Actualizar dimensiones
        this.width = newWidth;
        this.height = newHeight;
    
        // 3. Redimensionar las 4 líneas de forma independiente sin mover el origen
        up.changeSize(thickness, width);
        down.changeSize(thickness, width);
        left.changeSize(height, thickness);
        right.changeSize(height, thickness);
    
        // 4. Posicionar nuevamente down y right según el nuevo tamaño
        down.moveVertical(this.height - this.thickness);
        right.moveHorizontal(this.width - this.thickness);
    
        if (estabaVisible) makeVisible();
    }

    /**
     * Cambia el color del borde.
     * @param color Nombre del color en estándar CSS o BlueJ.
     */
    // Invariante: Asigna simultáneamente el mismo color a los cuatro lados del marco.
    public void changeColor(String color) {
        up.changeColor(color);
        down.changeColor(color);
        left.changeColor(color);
        right.changeColor(color);
    }

    /**
     * Muestra el marco en la pantalla.
     */
    // Invariante: Cambia el estado isVisible a true y hace visibles individualmente cada uno de los cuatro lados del rectángulo.
    public void makeVisible() {
        isVisible = true;
        up.makeVisible();
        down.makeVisible();
        left.makeVisible();
        right.makeVisible();
    }

    /**
     * Oculta el marco de la pantalla.
     */
    // Invariante: Cambia el estado isVisible a false y oculta individualmente cada uno de los cuatro lados del rectángulo.
    public void makeInvisible() {
        isVisible = false;
        up.makeInvisible();
        down.makeInvisible();
        left.makeInvisible();
        right.makeInvisible();
    }

    /**
     * Desplaza el marco horizontalmente.
     * @param distance Cantidad de píxeles a mover en el eje X.
     */
    // Invariante: Aplica un desplazamiento horizontal exactamente de la cantidad de píxeles indicada a los cuatro lados del marco.
    public void moveHorizontal(int distance) {
        this.x += distance; 
        up.moveHorizontal(distance);
        down.moveHorizontal(distance);
        left.moveHorizontal(distance);
        right.moveHorizontal(distance);
    }

    /**
     * Desplaza el marco verticalmente.
     * @param distance Cantidad de píxeles a mover en el eje Y.
     */
    // Invariante: Aplica un desplazamiento vertical exactamente de la cantidad de píxeles indicada a los cuatro lados del marco.
    public void moveVertical(int distance) {
        this.y += distance;
        up.moveVertical(distance);
        down.moveVertical(distance);
        left.moveVertical(distance);
        right.moveVertical(distance);
    }
    
    /**
     * Devuelve la posición actual en el eje X del borde/rectángulo.
     * @return coordenada X actual.
     */
    public int getPositionX() {
        return this.x;
    }

    /**
     * Devuelve la posición actual en el eje Y del borde/rectángulo.
     * @return coordenada Y actual.
     */
    public int getPositionY() {
        return this.y;
    }        
}