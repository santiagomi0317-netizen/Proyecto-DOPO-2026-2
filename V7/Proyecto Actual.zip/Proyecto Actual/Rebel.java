
/**
 * Write a description of class rebel here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Rebel{

}