
/**
 * Clase que hereda de symbol NormalS la cual no tiene un comportamiento particular
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NormalS extends Symbol{
    /**
     * Constructor para instanciar un nuevo Symbol NormalS.
     * 
     * @param color identificador del color (ej. "red", "blue", "yellow")
     * @param forma tipo de figura geométrica ("Triangle", "Circle", "Rectangle")
     */
    public NormalS(String color, String forma){
        super(color, forma);
    
    } 
    
    /**
     * Implementacion personalizada para rodar y que el simbolo se reeuce su tamaño
     */
    @Override
    protected void onSelected(){
        return;
    }
    
    /**
     * Implementacion personalizada intercambiar la visibilidad
     */
    @Override
    protected void onSpin(){
        return;
    }
    
    /**
     * Implementacion personalizada para generar una copia del catalogo 
     * @return Symbol(Shy)
     */
    @Override
    public Symbol copy() { 
        return new NormalS(getColor(), getForm());
    }
}