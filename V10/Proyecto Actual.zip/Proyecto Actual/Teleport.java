import java.util.ArrayList;
/**
 * Clase de rueda Teleport la cual Antes de cada Spin este tipo de rueda se teletransporta a una de tipo teleport, normal o lefty
 * 
 * @author (Santiago Murillo) 
 * @version (a version number or a date)
 */
public class Teleport extends Wheel{
    /**
     * Constructor para instanciar una rueda de tipo  Teleport.
     * @param symbols ArrayList<Symbol>, catalogo de Simbolos
     */
    public Teleport(ArrayList<Symbol> symbols) throws SlotMachineException {
        super(symbols);
        border.changeColor("yellow");
    } 
    
    /**
     * Permiso de teletransporte
     * @return true, ya que esta es su skill
     */
    @Override 
    public boolean teleports() { return true; }
    
    /**
     * Manejo personalizado del borde amarillo
     */
    @Override 
    protected String defaultBorderColor() { return "yellow"; }
}