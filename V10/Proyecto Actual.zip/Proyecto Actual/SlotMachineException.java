/**
* Clase implemntada para manejar las excepciones de SlotMachine
*/

public class SlotMachineException extends Exception {
    public static final String MINIUM_WHEELS = "A slotmachine requires at least 3 wheels";
    public static final String MAX_WHEELS = "A slotmachine supports at most 50 wheels";
    public static final String WHEEL_NOT_IN_TYPE = "The wheel type is not supported";
    public static final String INDEX_OUT_OF_BOUNDS = "The index is more or less of the actual wheels.";
    public static final String REBEL_TYPE = "The actual wheel cant be delete, because is Rebel";
    public static final String NULL_COLOR = "The color cant be empty or null";
    public static final String CSS_COLOR = "The color dont pass the CSS standar";
    public static final String REPEAT_COLOR = "The color is already working";
    public static final String SYMBOL_NOT_FOUND= "Symbol not found";
    public static final String ACTUAL_SYMBOL_ON_LOCKED_WHEEL= "A locked wheel has this Symbol in its configuration";
    public static final String LOCKED_WHEEL= "Wheel locked";
    public static final String NULL_WHEEL = "Wheel dont exists";
    public static final String NULL_SYMBOL = "Symbol dont exists";
    public static final String EMPTY_SYMBOLS = "Catalog of symbols Empty";
    public static final String SAME_WHEELS = "Same wheels";
    public static final String CONFIGURATION_ARRAY_WEIRD = "The array dont satisfy the size of the wheels";
    public static final String WRONG_TYPE = "The type dont pass the standar";
    public static final String WRONG_FORM = "The type dont pass the standar";
 
    

    public SlotMachineException(String message) {
        super(message);
    }
}