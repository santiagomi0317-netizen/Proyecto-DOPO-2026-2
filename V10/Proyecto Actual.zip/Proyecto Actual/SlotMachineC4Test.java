import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Pruebas de unidad del ciclo 4: tipos de rueda (normal, rebel, lefty, teleport)
 * y tipos de símbolo (normal, shy, ephemeral).
 *
 * Supuestos: new SlotMachine() crea una máquina vacía e invisible,
 * wheelAt y symbolAt usan posiciones desde 1, y la clase del símbolo normal es NormalS.
 * addWheel exige un catálogo con al menos un símbolo (si no, lanza EMPTY_SYMBOLS),
 * por eso cada prueba de ruedas llena el catálogo primero.
 *
 * @author Santiago Murillo
 * @version 4.0
 * Implementado con IA
 */
public class SlotMachineC4Test {
    private SlotMachine machine;

    /**
     * Crea una máquina vacía e invisible antes de cada prueba.
     */
    @BeforeEach
    public void setUp() {
        machine = new SlotMachine();
    }

    /**
     * Libera los recursos después de cada prueba.
     */
    @AfterEach
    public void tearDown() {
        machine = null;
    }

    /**
     * Agrega tres símbolos al catálogo: red, blue y green.
     */
    private void fillCatalog() throws SlotMachineException {
        machine.addSymbol("red", "circle");
        machine.addSymbol("blue", "circle");
        machine.addSymbol("green", "circle");
    }

    // =========================================================================
    // RUEDAS - NormalW
    // =========================================================================

    /**
     * ¿Qué debería hacer? Agregar una rueda normal en la posición pedida y marcar ok en true.
     * ¿Qué no debería hacer? Crear una rueda de otro tipo ni marcar ok en false.
     */
    @Test
    public void normalWheelIsAdded() throws SlotMachineException {
        fillCatalog();
        machine.addWheel("normal", 1);
        assertTrue(machine.ok());
        assertTrue(machine.wheelAt(1) instanceof NormalW);
    }

    /**
     * ¿Qué debería hacer? Mostrar un símbolo del catálogo después de girar.
     * ¿Qué no debería hacer? Quedarse vacía ni mostrar un color que no esté en el catálogo.
     */
    @Test
    public void normalWheelShowsCatalogSymbolAfterSpin() throws SlotMachineException {
        machine.addSymbol("red", "circle");
        machine.addWheel("normal", 1);
        machine.spin();
        assertEquals("red", machine.configuration()[0]);
    }

    /**
     * ¿Qué debería hacer? Bloquearse y conservar su símbolo aunque se gire la máquina.
     * ¿Qué no debería hacer? Cambiar de símbolo mientras está bloqueada.
     */
    @Test
    public void lockedNormalWheelDoesNotSpin() throws SlotMachineException {
        fillCatalog();
        machine.addWheel("normal", 1);
        machine.placeSymbol(1, "red");
        machine.lock(1);
        assertTrue(machine.wheelAt(1).isLocked());
        for (int i = 0; i < 20; i++) machine.spin();
        assertEquals("red", machine.configuration()[0]);
    }

    /**
     * ¿Qué debería hacer? Eliminarse cuando hay más de tres ruedas.
     * ¿Qué no debería hacer? Quedar en la máquina ni marcar ok en false.
     */
    @Test
    public void normalWheelCanBeDeletedWithMoreThanThree() throws SlotMachineException {
        fillCatalog();
        for (int i = 1; i <= 4; i++) machine.addWheel("normal", i);
        machine.delWheel(4);
        assertTrue(machine.ok());
        assertNull(machine.wheelAt(4));
    }

    /**
     * ¿Qué debería hacer? Intercambiar su posición con otra rueda intercambiable.
     * ¿Qué no debería hacer? Marcar ok en false ni dejar las ruedas en su lugar original.
     */
    @Test
    public void normalWheelCanBeSwapped() throws SlotMachineException {
        fillCatalog();
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        Wheel a = machine.wheelAt(1), b = machine.wheelAt(2);
        machine.swap(1, 2);
        assertTrue(machine.ok());
        assertSame(b, machine.wheelAt(1));
        assertSame(a, machine.wheelAt(2));
    }

    // =========================================================================
    // RUEDAS - Rebel
    // =========================================================================

    /**
     * ¿Qué debería hacer? Rechazar el bloqueo: ok en false y la rueda sigue desbloqueada.
     * (lock NO lanza excepción en este caso: solo marca ok en false y retorna.)
     * ¿Qué no debería hacer? Quedar bloqueada.
     */
    @Test
    public void rebelWheelCannotBeLocked() throws SlotMachineException {
        fillCatalog();
        machine.addWheel("rebel", 1);
        machine.lock(1);
        assertFalse(machine.ok());
        assertFalse(machine.wheelAt(1).isLocked());
    }

    /**
     * ¿Qué debería hacer? Lanzar SlotMachineException (REBEL_TYPE) y seguir en su posición.
     * ¿Qué no debería hacer? Desaparecer de la máquina ni marcar ok en true.
     */
    @Test
    public void rebelWheelCannotBeDeleted() throws SlotMachineException {
        fillCatalog();
        for (int i = 1; i <= 3; i++) machine.addWheel("normal", i);
        machine.addWheel("rebel", 4);
        assertThrows(SlotMachineException.class, () -> machine.delWheel(4));
        assertFalse(machine.ok());
        assertTrue(machine.wheelAt(4) instanceof Rebel);
    }

    /**
     * ¿Qué debería hacer? Lanzar SlotMachineException (REBEL_TYPE) y conservar su posición.
     * ¿Qué no debería hacer? Cambiar de lugar ni marcar ok en true.
     */
    @Test
    public void rebelWheelCannotBeSwapped() throws SlotMachineException {
        fillCatalog();
        machine.addWheel("rebel", 1);
        machine.addWheel("normal", 2);
        Wheel r = machine.wheelAt(1);
        assertThrows(SlotMachineException.class, () -> machine.swap(1, 2));
        assertFalse(machine.ok());
        assertSame(r, machine.wheelAt(1));
    }

    /**
     * ¿Qué debería hacer? Girar como una rueda normal y mostrar un símbolo del catálogo.
     * ¿Qué no debería hacer? Quedarse sin símbolo ni rechazar el giro.
     */
    @Test
    public void rebelWheelSpinsNormally() throws SlotMachineException {
        fillCatalog();
        machine.addWheel("rebel", 1);
        machine.spin();
        assertTrue(machine.ok());
        assertNotNull(machine.configuration()[0]);
    }

    /**
     * ¿Qué debería hacer? Aceptar unlock sin error aunque nunca haya estado bloqueada.
     * ¿Qué no debería hacer? Lanzar excepción ni marcar ok en false.
     */
    @Test
    public void unlockOnRebelWheelDoesNotFail() throws SlotMachineException {
        fillCatalog();
        machine.addWheel("rebel", 1);
        machine.unlock(1);
        assertTrue(machine.ok());
    }

    // =========================================================================
    // RUEDAS - Lefty
    // =========================================================================

    /**
     * ¿Qué debería hacer? Mostrar siempre el mismo color que su vecina izquierda tras girar.
     * ¿Qué no debería hacer? Elegir un símbolo distinto al de la vecina.
     */
    @Test
    public void leftyWheelCopiesLeftNeighborOnSpin() throws SlotMachineException {
        machine.addSymbol("red", "circle");
        machine.addSymbol("blue", "circle");
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        for (int i = 0; i < 15; i++) {
            machine.spin();
            String[] c = machine.configuration();
            assertEquals(c[0], c[1]);
        }
    }

    /**
     * ¿Qué debería hacer? Girar como una rueda normal si no tiene vecina a la izquierda.
     * ¿Qué no debería hacer? Lanzar excepción ni quedarse sin símbolo.
     */
    @Test
    public void leftyWheelWithoutNeighborSpinsNormally() throws SlotMachineException {
        fillCatalog();
        machine.addWheel("lefty", 1);
        machine.spin();
        assertTrue(machine.ok());
        assertNotNull(machine.configuration()[0]);
    }

    /**
     * ¿Qué debería hacer? Propagar el símbolo en cadena: normal, lefty y lefty quedan iguales.
     * ¿Qué no debería hacer? Copiar un estado anterior porque giró antes que su vecina.
     */
    @Test
    public void chainedLeftyWheelsEndUpEqual() throws SlotMachineException {
        fillCatalog();
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        machine.addWheel("lefty", 3);
        machine.spin();
        String[] c = machine.configuration();
        assertEquals(c[0], c[1]);
        assertEquals(c[1], c[2]);
    }

    /**
     * ¿Qué debería hacer? Conservar su símbolo si está bloqueada, aunque la vecina cambie.
     * ¿Qué no debería hacer? Copiar a la vecina mientras está bloqueada.
     */
    @Test
    public void lockedLeftyWheelDoesNotCopy() throws SlotMachineException {
        fillCatalog();
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        String lefty = machine.configuration()[1];
        machine.addSymbol("brown", "");
        machine.lock(2);
        machine.placeSymbol(1, "brown");
        for (int i = 0; i < 10; i++) machine.spin();
        assertEquals(lefty, machine.configuration()[1]);
    }

    /**
     * ¿Qué debería hacer? Mostrar el símbolo de su nueva vecina inmediatamente después de un swap.
     * ¿Qué no debería hacer? Quedarse con el símbolo de su antigua vecina.
     * (Requiere syncNeighbors en swap.)
     */
    @Test
    public void leftyWheelCopiesNewNeighborAfterSwap() throws SlotMachineException {
        machine.addSymbol("red", "circle");
        machine.addSymbol("blue", "circle");
        machine.addWheel("normal", 1);
        machine.addWheel("normal", 2);
        machine.addWheel("lefty", 3);
        machine.placeSymbol(1, "red");
        machine.placeSymbol(2, "blue");
        machine.swap(2, 3);
        String[] c = machine.configuration();
        assertEquals(c[0], c[1]);
    }

    // =========================================================================
    // RUEDAS - Teleport
    // =========================================================================

    /**
     * ¿Qué debería hacer? Agregar una rueda teleport en la posición pedida.
     * ¿Qué no debería hacer? Crear otro tipo de rueda ni marcar ok en false.
     */
    @Test
    public void teleportWheelIsAdded() throws SlotMachineException {
        fillCatalog();
        machine.addWheel("teleport", 1);
        assertTrue(machine.ok());
        assertTrue(machine.wheelAt(1) instanceof Teleport);
    }

    /**
     * ¿Qué debería hacer? Cambiar de posición en algún giro (prueba probabilística, 40 intentos).
     * ¿Qué no debería hacer? Quedarse siempre en la posición inicial.
     */
    @Test
    public void teleportWheelChangesPosition() throws SlotMachineException {
        fillCatalog();
        machine.addWheel("teleport", 1);
        machine.addWheel("normal", 2);
        machine.addWheel("normal", 3);
        Wheel t = machine.wheelAt(1);
        boolean moved = false;
        for (int i = 0; i < 40 && !moved; i++) {
            machine.spin();
            moved = machine.wheelAt(1) != t;
        }
        assertTrue(moved);
    }

    /**
     * ¿Qué debería hacer? Dejar la rueda rebel en su posición en todos los giros.
     * ¿Qué no debería hacer? Intercambiarse con una rueda rebel.
     */
    @Test
    public void teleportWheelNeverSwapsWithRebel() throws SlotMachineException {
        fillCatalog();
        machine.addWheel("rebel", 1);
        machine.addWheel("teleport", 2);
        machine.addWheel("normal", 3);
        Wheel r = machine.wheelAt(1);
        for (int i = 0; i < 30; i++) machine.spin();
        assertSame(r, machine.wheelAt(1));
    }

    /**
     * ¿Qué debería hacer? Quedarse quieta si todas las demás ruedas son rebel.
     * ¿Qué no debería hacer? Lanzar excepción ni moverse a una posición ocupada por una rebel.
     */
    @Test
    public void teleportWheelStaysIfAllOthersAreRebel() throws SlotMachineException {
        fillCatalog();
        machine.addWheel("teleport", 1);
        machine.addWheel("rebel", 2);
        machine.addWheel("rebel", 3);
        Wheel t = machine.wheelAt(1);
        for (int i = 0; i < 10; i++) machine.spin();
        assertSame(t, machine.wheelAt(1));
    }

    /**
     * ¿Qué debería hacer? Quedarse en su posición si está bloqueada.
     * ¿Qué no debería hacer? Teletransportarse mientras está bloqueada.
     */
    @Test
    public void lockedTeleportWheelDoesNotMove() throws SlotMachineException {
        fillCatalog();
        machine.addWheel("teleport", 1);
        machine.addWheel("normal", 2);
        machine.addWheel("normal", 3);
        Wheel t = machine.wheelAt(1);
        machine.lock(1);
        for (int i = 0; i < 20; i++) machine.spin();
        assertSame(t, machine.wheelAt(1));
    }

    /**
     * ¿Qué debería hacer? Mantener el mismo número de ruedas después de teletransportarse.
     * ¿Qué no debería hacer? Duplicar ni perder ruedas.
     */
    @Test
    public void teleportWheelKeepsWheelCount() throws SlotMachineException {
        fillCatalog();
        machine.addWheel("teleport", 1);
        machine.addWheel("normal", 2);
        machine.addWheel("normal", 3);
        for (int i = 0; i < 10; i++) machine.spin();
        assertNotNull(machine.wheelAt(3));
        assertNull(machine.wheelAt(4));
    }

    // =========================================================================
    // RUEDAS - Tipo inválido
    // =========================================================================

    /**
     * ¿Qué debería hacer? Lanzar SlotMachineException (WHEEL_NOT_IN_TYPE) con ok en false.
     * ¿Qué no debería hacer? Agregar ninguna rueda.
     * (Hay que llenar el catálogo: si no, la excepción sería EMPTY_SYMBOLS y no probaría el tipo.)
     */
    @Test
    public void invalidWheelTypeIsNotAdded() throws SlotMachineException {
        fillCatalog();
        assertThrows(SlotMachineException.class, () -> machine.addWheel("foo", 1));
        assertFalse(machine.ok());
        assertNull(machine.wheelAt(1));
    }

    // =========================================================================
    // SÍMBOLOS - Normal
    // =========================================================================

    /**
     * ¿Qué debería hacer? Agregar al catálogo un símbolo de tipo normal.
     * ¿Qué no debería hacer? Crear otro tipo de símbolo ni marcar ok en false.
     */
    @Test
    public void normalSymbolIsAddedToCatalog() throws SlotMachineException {
        machine.addSymbol("red", "circle", "normal");
        assertTrue(machine.ok());
        assertTrue(machine.symbolAt(1) instanceof NormalS);
    }

    /**
     * ¿Qué debería hacer? No cambiar nada al girar ni al ser seleccionado.
     * ¿Qué no debería hacer? Cambiar su visibilidad, su color ni su forma.
     */
    @Test
    public void normalSymbolDoesNotChangeOnSpinOrSelection() {
        Symbol s = new NormalS("blue", "triangle");
        s.onSpin();
        s.onSelected();
        assertEquals("blue", s.getColor());
        assertEquals("triangle", s.getForm());
        assertFalse(s.isVisible);
    }

    /**
     * ¿Qué debería hacer? Crear un objeto nuevo del mismo tipo, color y forma.
     * ¿Qué no debería hacer? Devolver la misma instancia ni cambiar de tipo.
     */
    @Test
    public void normalSymbolCopyKeepsTypeColorAndShape() {
        Symbol s = new NormalS("blue", "rectangle");
        Symbol c = s.copy();
        assertTrue(c instanceof NormalS);
        assertNotSame(s, c);
        assertEquals(s.getColor(), c.getColor());
        assertEquals(s.getForm(), c.getForm());
    }

    // =========================================================================
    // SÍMBOLOS - Shy
    // =========================================================================

    /**
     * ¿Qué debería hacer? Agregar al catálogo un símbolo de tipo shy.
     * ¿Qué no debería hacer? Crear otro tipo de símbolo ni marcar ok en false.
     */
    @Test
    public void shySymbolIsAddedToCatalog() throws SlotMachineException {
        machine.addSymbol("pink", "circle", "shy");
        assertTrue(machine.ok());
        assertTrue(machine.symbolAt(1) instanceof Shy);
    }

    /**
     * ¿Qué debería hacer? Alternar entre escondido y visible cada vez que es seleccionado.
     * ¿Qué no debería hacer? Quedarse siempre visible ni siempre escondido.
     */
    @Test
    public void shySymbolTogglesWhenSelected() {
        Shy s = new Shy("red", "circle",false);
        s.onSelected();
        assertTrue(s.isHidden());

        s.onSelected();
        assertFalse(s.isHidden());
    }

    /**
     * ¿Qué debería hacer? Seguir invisible si dejó de estar escondido pero nadie lo pidió visible.
     * ¿Qué no debería hacer? Aparecer cuando la máquina está oculta.
     */
    @Test
    public void shySymbolDoesNotReappearIfMachineIsInvisible() {
        Shy s = new Shy("red", "circle",false);
        s.makeInvisible();
        s.onSelected();
        s.onSelected();
        assertFalse(s.isVisible);
    }

    /**
     * ¿Qué debería hacer? Crear una copia Shy con el mismo estado de timidez.
     * ¿Qué no debería hacer? Devolver otro tipo ni reiniciar hidden a false.
     */
    @Test
    public void shySymbolCopyKeepsTypeAndState() {
        Shy s = new Shy("red", "circle",false);
        s.onSelected();
        Symbol c = s.copy();
        assertTrue(c instanceof Shy);
        assertTrue(((Shy) c).isHidden());
    }

    /**
     * ¿Qué debería hacer? Alternar su estado cada vez que la rueda lo elige al girar.
     * ¿Qué no debería hacer? Quedarse igual después de girar.
     */
    @Test
    public void shySymbolTogglesWhenWheelPicksIt() throws SlotMachineException {
        machine.addSymbol("red", "circle", "shy");
        machine.addWheel("normal", 1);
        machine.spin();
        assertTrue(((Shy) machine.symbolAt(1)).isHidden());
        machine.spin();
        assertFalse(((Shy) machine.symbolAt(1)).isHidden());
    }

    /**
     * ¿Qué debería hacer? Contar por su color en configuration aunque esté escondido.
     * ¿Qué no debería hacer? Aparecer como null en la configuración.
     */
    @Test
    public void hiddenShySymbolStillCountsByColor() throws SlotMachineException {
        machine.addSymbol("red", "circle", "shy");
        machine.addWheel("normal", 1);
        machine.spin();
        assertEquals("red", machine.configuration()[0]);
    }

    // =========================================================================
    // SÍMBOLOS - Ephemeral
    // =========================================================================

    /**
     * ¿Qué debería hacer? Agregar al catálogo un símbolo de tipo ephemeral.
     * ¿Qué no debería hacer? Crear otro tipo de símbolo ni marcar ok en false.
     */
    @Test
    public void ephemeralSymbolIsAddedToCatalog() throws SlotMachineException {
        machine.addSymbol("gold", "circle", "ephemeral");
        assertTrue(machine.ok());
        assertTrue(machine.symbolAt(1) instanceof Ephemeral);
    }

    /**
     * ¿Qué debería hacer? Reducir su tamaño en cada giro.
     * ¿Qué no debería hacer? Mantener o aumentar su tamaño.
     */
    @Test
    public void ephemeralSymbolShrinksOnEverySpin() {
        Ephemeral e = new Ephemeral("red", "circle");
        int before = e.getSize();
        e.onSpin();
        assertTrue(e.getSize() < before);
    }

    /**
     * ¿Qué debería hacer? Detenerse en tamaño 1 (un punto) sin importar cuántos giros haya.
     * ¿Qué no debería hacer? Llegar a 0 ni a un tamaño negativo.
     */
    @Test
    public void ephemeralSymbolNeverGoesBelowOneDot() {
        Ephemeral e = new Ephemeral("red", "rectangle");
        for (int i = 0; i < 30; i++) e.onSpin();
        assertEquals(1, e.getSize());
    }

    /**
     * ¿Qué debería hacer? Ignorar la selección: onSelected no cambia su tamaño.
     * ¿Qué no debería hacer? Encogerse por ser seleccionado.
     */
    @Test
    public void ephemeralSymbolIgnoresSelection() {
        Ephemeral e = new Ephemeral("red", "circle");
        int before = e.getSize();
        e.onSelected();
        assertEquals(before, e.getSize());
    }

    /**
     * ¿Qué debería hacer? Verificar que el tamaño del simbolo del catalogo disminuyo
     * ¿Qué no debería hacer? Volver al tamaño inicial
     */
    @Test
    public void ephemeralSymbolCopyKeepsTypeAndSize() {
        Ephemeral e = new Ephemeral("red", "circle");
        int size1 = e.getSize();
        e.onSpin();
        int size2 = e.getSize();
               assertEquals(size1, size2 + 5);
    }

    /**
     * ¿Qué debería hacer? Encogerse cuando la rueda lo elige al girar.
     * ¿Qué no debería hacer? Mantener su tamaño después del giro.
     */
    @Test
    public void ephemeralSymbolShrinksWhenWheelPicksIt() throws SlotMachineException {
        machine.addSymbol("gold", "circle", "ephemeral");
        machine.addWheel("normal", 1);
        int before = ((Ephemeral) machine.symbolAt(1)).getSize();
        machine.spin();
        assertTrue(((Ephemeral) machine.symbolAt(1)).getSize() < before);
    }

    /**
     * ¿Qué debería hacer? Conservar su tamaño cuando se coloca a mano con placeSymbol.
     * ¿Qué no debería hacer? Encogerse por una colocación que no es un giro.
     */
    @Test
    public void ephemeralSymbolDoesNotShrinkWhenPlacedManually() throws SlotMachineException {
        machine.addSymbol("gold", "circle", "ephemeral");
        machine.addWheel("normal", 1);
        int before = ((Ephemeral) machine.symbolAt(1)).getSize();
        machine.placeSymbol(1, "gold");
        assertEquals(before, ((Ephemeral) machine.symbolAt(1)).getSize());
    }
}