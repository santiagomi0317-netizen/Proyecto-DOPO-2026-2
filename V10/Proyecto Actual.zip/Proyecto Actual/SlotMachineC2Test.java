import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class SlotMachineC2Test.
 *
 * @author  (Santiago Murillo)
 * @version (16 de septiembre)
 */
public class SlotMachineC2Test {
    private SlotMachine machine;

    /**
     * Crea una maquina invisible con EXACTAMENTE 3 simbolos y 3 ruedas normales.
     * No usamos new SlotMachine(false) porque ese constructor crea 4 ruedas de
     * tipos distintos (normal, rebel, lefty, teleport) y estas pruebas asumen 3 normales.
     */
    @BeforeEach
    public void setUp() throws SlotMachineException {
        machine = new SlotMachine();
        machine.addSymbol("aquamarine", "circle");
        machine.addSymbol("bisque", "triangle");
        machine.addSymbol("black", "rectangle");
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addWheel(3);
    }

    @AfterEach
    public void tearDown() throws SlotMachineException {
        machine = null;
    }

    // =========================================================================
    // CICLO DOS
    // =========================================================================
    // swap(wheel1 : int, wheel2 : int) : void
    // =========================================================================

    /**
     * ¿Qué debería hacer? Intercambiar dos ruedas validas (ok en true).
     * ¿Qué no debería hacer? Lanzar excepcion con indices correctos.
     */
    @Test
    public void shouldSwapTwoValidWheels() throws SlotMachineException {
        String[] initialSymbols = machine.configuration();
        machine.swap(1, 2);
        String[] currentSymbols = machine.configuration();

        assertTrue(machine.ok());
        assertEquals(initialSymbols[0], currentSymbols[1]);
        assertEquals(initialSymbols[1], currentSymbols[0]);
    }

    /**
     * ¿Qué debería hacer? Lanzar SlotMachineException (INDEX_OUT_OF_BOUNDS) y dejar ok en false.
     * ¿Qué no debería hacer? Cambiar la configuracion ni lanzar IndexOutOfBoundsException.
     */
    @Test
    public void shouldNotSwapInvalidWheelIndex() {
        String[] initialSymbols = machine.configuration();
        assertThrows(SlotMachineException.class, () -> machine.swap(1, 4));
        assertFalse(machine.ok());
        assertArrayEquals(initialSymbols, machine.configuration());
    }

    /**
     * ¿Qué debería hacer? Lanzar SlotMachineException (SAME_WHEELS) y dejar ok en false.
     * ¿Qué no debería hacer? Hacer un intercambio redundante.
     */
    @Test
    public void shouldNotSwapSameWheel() {
        String[] initialSymbols = machine.configuration();
        assertThrows(SlotMachineException.class, () -> machine.swap(1, 1));
        assertFalse(machine.ok());
        assertArrayEquals(initialSymbols, machine.configuration());
    }

    /**
     * ¿Qué debería hacer? Lanzar SlotMachineException con indice negativo y ok en false.
     * ¿Qué no debería hacer? Aceptar posiciones menores a 1.
     */
    @Test
    public void shouldNotSwapWithNegativeIndex() {
        String[] initialSymbols = machine.configuration();
        assertThrows(SlotMachineException.class, () -> machine.swap(-1, 3));
        assertFalse(machine.ok());
        assertArrayEquals(initialSymbols, machine.configuration());
    }

    // =========================================================================
    // lock(wheel : int) : void
    // =========================================================================

    /**
     * ¿Qué debería hacer? Bloquear la rueda; despues, girarla debe lanzar excepcion (LOCKED_WHEEL).
     * ¿Qué no debería hacer? Permitir que una rueda bloqueada siga girando.
     */
    @Test
    public void shouldlockValidWheel() throws SlotMachineException {
        machine.lock(1);
        assertTrue(machine.ok());

        String originalSymbol = machine.configuration()[0];
        assertThrows(SlotMachineException.class, () -> machine.spin(1, 3));

        assertFalse(machine.ok());
        assertEquals(originalSymbol, machine.configuration()[0]);
    }

    /**
     * ¿Qué debería hacer? Lanzar SlotMachineException (NULL_WHEEL) con indice negativo.
     * ¿Qué no debería hacer? Bloquear alguna rueda.
     */
    @Test
    public void shouldNotlockInvalidWheelMin() {
        assertThrows(SlotMachineException.class, () -> machine.lock(-1));
        assertFalse(machine.ok());
        for (int i = 1; i < 4; i++) {
            assertFalse(machine.wheelAt(i).isLocked());
        }
    }

    /**
     * ¿Qué debería hacer? Lanzar SlotMachineException (NULL_WHEEL) cuando el indice excede las ruedas.
     * ¿Qué no debería hacer? Bloquear alguna rueda.
     */
    @Test
    public void shouldNotlockInvalidWheelMor() {
        assertThrows(SlotMachineException.class, () -> machine.lock(4));
        assertFalse(machine.ok());
        for (int i = 1; i < 4; i++) {
            assertFalse(machine.wheelAt(i).isLocked());
        }
    }

    // =========================================================================
    // unlock(wheel : int) : void
    // =========================================================================

    /**
     * ¿Qué debería hacer? Desbloquear una rueda valida previamente bloqueada (ok en true).
     * ¿Qué no debería hacer? Dejarla bloqueada.
     */
    @Test
    public void shouldUnlockValidWheel() throws SlotMachineException {
        machine.lock(1);
        machine.unlock(1);
        assertTrue(machine.ok());
        assertFalse(machine.wheelAt(1).isLocked());
    }

    /**
     * ¿Qué debería hacer? Lanzar SlotMachineException (NULL_WHEEL) con indice negativo.
     * ¿Qué no debería hacer? Alterar el bloqueo de las ruedas existentes.
     */
    @Test
    public void shouldNotUnlockInvalidWheelMin() throws SlotMachineException {
        machine.lock(1);
        machine.lock(2);
        machine.lock(3);
        assertThrows(SlotMachineException.class, () -> machine.unlock(-1));
        assertFalse(machine.ok());

        for (int i = 1; i < 4; i++) {
            assertTrue(machine.wheelAt(i).isLocked());
        }
    }

    /**
     * ¿Qué debería hacer? Lanzar SlotMachineException (NULL_WHEEL) con indice fuera de rango.
     * ¿Qué no debería hacer? Desbloquear alguna rueda.
     */
    @Test
    public void shouldNotUnlockInvalidWheelMor() throws SlotMachineException {
        machine.lock(1);
        machine.lock(2);
        machine.lock(3);
        assertThrows(SlotMachineException.class, () -> machine.unlock(4));
        assertFalse(machine.ok());

        for (int i = 1; i < 4; i++) {
            assertTrue(machine.wheelAt(i).isLocked());
        }
    }

    // =========================================================================
    // spin(int wheel, int steps) : void
    // =========================================================================

    /**
     * ¿Qué debería hacer? Girar 3 pasos con 3 simbolos: da la vuelta completa y vuelve al mismo (ok en true).
     * ¿Qué no debería hacer? Lanzar excepcion con rueda desbloqueada y pasos validos.
     */
    @Test
    public void shouldSpinSteps() throws SlotMachineException {
        String firstSymbol = machine.configuration()[0];
        machine.spin(1, 3);
        String currentSymbol = machine.configuration()[0];

        assertTrue(machine.ok());
        assertEquals(firstSymbol, currentSymbol);
    }

    /**
     * ¿Qué debería hacer? Lanzar SlotMachineException (NULL_WHEEL) con rueda negativa.
     * ¿Qué no debería hacer? Mover ninguna rueda.
     */
    @Test
    public void shouldNotSpinStepsWheelMin() {
        String[] initialSymbols = machine.configuration();
        assertThrows(SlotMachineException.class, () -> machine.spin(-1, 2));
        assertFalse(machine.ok());
        assertArrayEquals(initialSymbols, machine.configuration());
    }

    /**
     * ¿Qué debería hacer? Lanzar SlotMachineException (NULL_WHEEL) si la rueda supera el total.
     * ¿Qué no debería hacer? Acceder fuera de los limites de la lista.
     */
    @Test
    public void shouldNotSpinStepsWheelMax() {
        String[] initialSymbols = machine.configuration();
        assertThrows(SlotMachineException.class, () -> machine.spin(4, 2));
        assertFalse(machine.ok());
        assertArrayEquals(initialSymbols, machine.configuration());
    }

    /**
     * ¿Qué debería hacer? Lanzar SlotMachineException (EMPTY_SYMBOLS) si el catalogo esta vacio.
     * ¿Qué no debería hacer? Girar sin simbolos disponibles.
     */
    @Test
    public void shouldNotSpinStepsWheelSymbolsEmpty() throws SlotMachineException {
        machine.delSymbol("aquamarine");
        machine.delSymbol("bisque");
        machine.delSymbol("black");
        assertThrows(SlotMachineException.class, () -> machine.spin(1, 3));
        assertFalse(machine.ok());
    }

    /**
     * ¿Qué debería hacer? Lanzar SlotMachineException (LOCKED_WHEEL) si la rueda esta bloqueada.
     * ¿Qué no debería hacer? Mover una rueda fijada.
     */
    @Test
    public void shouldNotSpinStepsWheelLocked() throws SlotMachineException {
        String[] initialSymbols = machine.configuration();
        machine.lock(1);
        assertThrows(SlotMachineException.class, () -> machine.spin(1, 3));
        assertFalse(machine.ok());
        assertArrayEquals(initialSymbols, machine.configuration());
    }

    // =========================================================================
    // spin(String[] symbolstoput) : void
    // =========================================================================

    /**
     * ¿Qué debería hacer? Aplicar la configuracion recibida (ok en true).
     * ¿Qué no debería hacer? Rechazar un arreglo valido del tamaño correcto.
     */
    @Test
    public void shouldSpinSetSymbols1() throws SlotMachineException {
        String[] symbolstoput = {"black", "black", "black"};
        machine.spin(symbolstoput);
        assertTrue(machine.isJackpot());
        assertTrue(machine.ok());
        assertArrayEquals(symbolstoput, machine.configuration());
    }

    /**
     * ¿Qué debería hacer? Establecer una combinacion con colores distintos (ok en true).
     * ¿Qué no debería hacer? Fallar con simbolos registrados.
     */
    @Test
    public void shouldSpinSetSymbols2() throws SlotMachineException {
        String[] symbolstoput = {"bisque", "black", "aquamarine"};
        machine.spin(symbolstoput);

        assertTrue(machine.ok());
        assertArrayEquals(symbolstoput, machine.configuration());
    }

    /**
     * ¿Qué debería hacer? Lanzar SlotMachineException (CONFIGURATION_ARRAY_WEIRD) si el arreglo es null.
     * ¿Qué no debería hacer? Lanzar NullPointerException.
     */
    @Test
    public void shouldnotSpinWithArrayNull() {
        String[] initialSymbols = machine.configuration();
        String[] symbolstoput = null;
        assertThrows(SlotMachineException.class, () -> machine.spin(symbolstoput));
        assertFalse(machine.ok());
        assertArrayEquals(initialSymbols, machine.configuration());
    }

    /**
     * ¿Qué debería hacer? Lanzar SlotMachineException si el catalogo de simbolos esta vacio.
     * ¿Qué no debería hacer? Asignar colores que no existen en el catalogo.
     */
    @Test
    public void shouldNotSpinWithEmptySymbolsArray() throws SlotMachineException {
        machine.delSymbol("aquamarine");
        machine.delSymbol("bisque");
        machine.delSymbol("black");
        // Foto DESPUES de borrar: las ruedas ya quedaron sin simbolo (eso es lo que borra delSymbol)
        String[] beforeSpin = machine.configuration();

        String[] symbolstoput = {"red", "red", "red"};
        assertThrows(SlotMachineException.class, () -> machine.spin(symbolstoput));
        assertFalse(machine.ok());
        assertArrayEquals(beforeSpin, machine.configuration());
    }

    /**
     * ¿Qué debería hacer? Lanzar SlotMachineException si el tamaño del arreglo difiere del numero de ruedas.
     * ¿Qué no debería hacer? Actualizar parcialmente las ruedas.
     */
    @Test
    public void shouldNotSpinWithSymbolsLDifWheelsS() {
        String[] initialSymbols = machine.configuration();
        String[] symbolstoput = {"red", "brown"};
        assertThrows(SlotMachineException.class, () -> machine.spin(symbolstoput));
        assertFalse(machine.ok());
        assertArrayEquals(initialSymbols, machine.configuration());
    }
}