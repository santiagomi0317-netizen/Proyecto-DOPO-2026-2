
/**
 * Clase que hereda de symbol Ephemeral la cual cuando se realiza un spin() se reduce su tamaño
 * 
 * @author (your name) 
 * @version (Santiago Murill)
 */
public class Ephemeral extends Symbol{
    private static final int INITIAL_SIZE = 30;
    private static final int STEP = 5;
    private static final int MIN_SIZE = 1;   
    private int size;
    
    
     
    /**
     * Constructor para instanciar un nuevo Symbol Ephemeral.
     * 
     * @param color String, identificador del color (ej. "red", "blue", "yellow")
     * @param forma String, tipo de figura geométrica ("Triangle", "Circle", "Rectangle")
     */
    public Ephemeral(String color, String forma) {
        this(color, forma, INITIAL_SIZE);
    }

     
    /**
     * Constructor auxiliar para guardar el tamaño.    
     * 
     * @param color String, identificador del color (ej. "red", "blue", "yellow")
     * @param forma String, tipo de figura geométrica ("Triangle", "Circle", "Rectangle")
     */

    private Ephemeral(String color, String forma, int size) {
        super(color, forma);
        this.size = size;
        if (size != INITIAL_SIZE && getFigure() != null) {
            getFigure().resize(size);   
        }
    }
    
    @Override
    public void onSpin() {
        size = Math.max(MIN_SIZE, size - STEP);
        if (getFigure() != null) getFigure().resize(size);
    }
    
    /**
    * @return el tamaño actual en píxeles
    */
    public int getSize() {
        return size;
    }
    
    /**
     * Implementacion personalizada intercambiar la visibilidad
     */ 
    @Override
    protected void onSelected(){
        return;
    }
    
    /**
     * Implementacion personalizada para generar una copia del catalogo 
     * @return Symbol(Shy)
     */
    @Override
    public Symbol copy() { 
        return new Ephemeral(getColor(), getForm(), size); 
    }
}