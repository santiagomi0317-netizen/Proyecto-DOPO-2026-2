/**
 * Clase de symbol Shy la cual cuando se hace un spin() esta varia su visibilidad 
 * 
 * @author (Santiago Murillo) 
 * @version (a version number or a date)
 */
public class Shy extends Symbol{
    private boolean hidden;
    private boolean shown;
    
    /**
     * Constructor para instanciar un nuevo Symbol Shy.
     * 
     * @param color String, identificador del color (ej. "red", "blue", "yellow")
     * @param forma String, tipo de figura geométrica ("Triangle", "Circle", "Rectangle")
     * @param hidden boolean, dice si esta escondido porque quiere el simbolo
     */
    public Shy(String color, String forma, boolean hidden) {
        super(color, forma);
        this.hidden = hidden;
    }
    
    /**
     * Implementacion personalizada para implementar shown
     */
    @Override
    public void makeVisible() {
        shown = true;
        if (!hidden) super.makeVisible();
    }
    
    /**
     * Implementacion personalizada intercambiar la visibilidad
     */
    @Override
    public void onSelected() {
        hidden = !hidden;
        if (hidden) {
            super.makeInvisible();
        } else if (shown){
             super.makeVisible();
        }
    }
    
    /**
     * Getter de hidden
     * @return hidden boolean, dice si esta escondido  o no
     */
    public boolean isHidden() { 
        return hidden; 
    }
    
    /**
     * Implementacion personalizada para rodar y que el simbolo se reeuce su tamaño
     */
    @Override
    protected void onSpin(){
        return;
    }
    
    /**
     * Implementacion personalizada para generar una copia del catalogo 
     * @return Symbol(Shy)
     */
    @Override
    public Symbol copy() { 
        return new Shy(getColor(), getForm(), hidden); 
    }
}