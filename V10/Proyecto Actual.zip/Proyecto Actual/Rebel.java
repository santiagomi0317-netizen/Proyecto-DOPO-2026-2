import java.util.ArrayList;
/**
 * Clase que hereda de wheel y es de tipo Rebel, la cual no se puede borrar, intercambiar y bloquear
 * 
 * @author (Santiago Murillo) 
 * @version (a version number or a date)
 */
public class Rebel extends Wheel{
    /**
     * Constructor para instanciar una rueda de tipo  Rebel.
     * @param symbols ArrayList<Symbol>, catalogo de Simbolos
     */
    public Rebel(ArrayList<Symbol> symbols) throws SlotMachineException {
        super(symbols);
        border.changeColor("orange");
    } 
    
    /**
     * Permiso de bloqueo
     * @return true, ya que esta es su skill
     */
    @Override 
    public boolean canLock()   { return false; }
    
    /**
     * Permiso de intercambio
     * @return true, ya que esta es su skill
     */
    @Override
    public boolean canSwap()   { return false; }
    
    /**
     * Permiso de eliminar
     * @return true, ya que esta es su skill
     */
    @Override 
    public boolean canDelete() { return false; }
    
    /**
     * Manejo personalizado del borde naranja
     */
    @Override 
    protected String defaultBorderColor() { return "orange"; }
}