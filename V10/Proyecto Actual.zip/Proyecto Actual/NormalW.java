import java.util.ArrayList;

/**
 * Clase que hereda de wheel y es de tipo Normal, la cual tiene todas las eleccion de los ciclos anteriores
 * 
 * @author (Santiago Murillo) 
 * @version (a version number or a date)
 */
public class NormalW extends Wheel{
    /**
     * Constructor para instanciar una rueda de tipo NormalW.
     * @param symbols ArrayList<Symbol>, catalogo de Simbolos
     */
    public NormalW(ArrayList<Symbol> symbols) throws SlotMachineException {
        super(symbols);
    } 
    
    /**
     * Manejo personalizado del borde negro
     */
    @Override 
    protected String defaultBorderColor() { return "black"; }
}