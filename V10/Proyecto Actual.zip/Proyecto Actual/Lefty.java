import java.util.ArrayList;
/**
 * Clase que hereda de wheel y maneja el tipo Lefty, la cual siempre que su rueda a mano izquierda de diferente de null copia su simbolo actual
 * 
 * @author (Santiago Murillo) 
 * @version (a version number or a date)
 */
public class Lefty extends Wheel{
    /**
     * Constructor para instanciar una rueda de tipo  Lefty.
     * @param symbols ArrayList<Symbol>, catalogo de Simbolos
     */
    public Lefty(ArrayList<Symbol> symbols) throws SlotMachineException {
        super(symbols);
        border.changeColor("green");
    } 
    
    /**
     * Giro personalizado si hay una rueda a si izquierda diferente a null
     */
    @Override 
    protected void spin(ArrayList<Symbol> symbols, Wheel left) {
        if (isLocked()) return ;
        if (left != null && left.getActualSymbol() != null) {
            setSymbol(left.getActualSymbol());   // setSymbol hace copy(): conserva tipo y estado
        } else {
            super.spin(symbols, left);         // sin vecina, gira normal
        }
    }
    
    /**
     * Manejo personalizado del borde verde
     */
    @Override 
    protected String defaultBorderColor() { return "green"; }
    
    /**
     * Cuando ocurre un swap, del o add de una rueda a la izquierda de un de tipo Lefty, esta se acutalzia
     * @param left Wheel, rueda actual a mano izquierda de la Lefty
     */
    @Override
    public void onNeighborChanged(Wheel left) {
        if (isLocked()) return ;
        if (left != null && left.getActualSymbol() != null) {
            setSymbol(left.getActualSymbol());
        }
    }
    
}