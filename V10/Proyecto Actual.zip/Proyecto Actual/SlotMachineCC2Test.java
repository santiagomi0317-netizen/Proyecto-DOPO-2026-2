import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class SlotMachineCC2Test.
 *
 * @author  (Santiago Murillo)
 * @version (9 de septiembre)
 */
public class SlotMachineCC2Test {
    private SlotMachine machine;

    /**
     * Crea una maquina invisible con EXACTAMENTE 3 simbolos y 3 ruedas normales.
     * No usamos new SlotMachine(false) porque ese constructor crea 4 ruedas de
     * tipos distintos (normal, rebel, lefty, teleport).
     */
    @BeforeEach
    public void setUp() throws SlotMachineException {
        machine = new SlotMachine();
        machine.addSymbol("aquamarine", "circle");
        machine.addSymbol("bisque", "triangle");
        machine.addSymbol("black", "rectangle");
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addWheel(3);
    }

    /**
     * Liberar recursos depues de cada prueba unitaria
     */
    @AfterEach
    public void tearDown() {
        machine = null;
    }

    // =========================================================================
    // PRUEBAS COMPARTIDAS EN EL WIKI (Aporte de Santiago Murillo - Init: MuR)
    // =========================================================================

    /**
     * Prueba 1:
     * ¿Qué debería hacer? Permitir intercambiar (swap) dos ruedas aun si una esta bloqueada (lock),
     * manteniendo el estado de bloqueo en su nueva posicion.
     * ¿Qué no debería hacer? Cancelar el intercambio o perder el bloqueo tras la reubicacion.
     */
    @Test
    public void accordingMurShouldSwapLockedWheelsAndMaintainLockState() throws SlotMachineException {
        machine.lock(1);
        assertTrue(machine.ok());

        machine.swap(1, 2);
        assertTrue(machine.ok());

        // La rueda bloqueada ahora esta en la posicion 2: girarla lanza excepcion (LOCKED_WHEEL)
        assertThrows(SlotMachineException.class, () -> machine.spin(2, 3));
        assertFalse(machine.ok());

        // La rueda libre quedo en la posicion 1: gira sin problema
        machine.spin(1, 3);
        assertTrue(machine.ok());
    }

    /**
     * Prueba 2:
     * ¿Qué debería hacer? Aplicar spin(String[]) solo a las ruedas libres cuando hay una bloqueada.
     * ¿Qué no debería hacer? Modificar el simbolo de la rueda fijada.
     */
    @Test
    public void accordingMurShouldSpinUnlockedWheelsOnlyWhenArrayIsApplied() throws SlotMachineException {
        // Colores que SI existen en el catalogo
        machine.spin(new String[]{"black", "black", "black"});
        assertTrue(machine.ok());
        assertTrue(machine.isJackpot());

        machine.lock(2);
        assertTrue(machine.ok());

        machine.spin(new String[]{"bisque", "bisque", "bisque"});
        assertTrue(machine.ok());

        // La rueda 2 (bloqueada) conserva "black"; las demas cambian a "bisque"
        assertArrayEquals(new String[]{"bisque", "black", "bisque"}, machine.configuration());
        assertFalse(machine.isJackpot());
    }
}