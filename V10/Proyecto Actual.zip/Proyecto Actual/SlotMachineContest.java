import java.util.ArrayList;
import java.util.List;

/**
 * Solucion para el problema de SlotMachine
 * @author Santiago Murillo
 */
public class SlotMachineContest {
    private static final int MAX_ACTIONS = 10000;
    public static SlotMachine currentMachine;
    private static int totalActions;

    // Invariante paso 1: Siempre se deja todas las ruedas mostrando símbolos distintos.
    // Invariante paso 2: Dado que cada uno de los simbolos es diferente, puedo encontrar el patron el cual
    // represente una fila donde cada rueda tiene una posicion especifica con respecto a otra. Ese patron se refiere
    // a que puedo saber si dos ruedas tienen simbolos seguidos si cuando muevo una rueda una posicion hacia el
    // frente y la otra hacia atras obtengo que los distintos simbolos son los maximos, los cuales se indican con
    // k == n, guardando esa referencia puedo empezar a armar mi patron circular donde cada rueda tiene un
    // predecesor y sucesor.
    // Invariante paso 3: Dada esta fila, desciframos los movimientos necesarios para rodar gradualmente cada
    // rueda tomando un punto de referencia.
    // Fue implementada con ayuda de Claude

    /**
     * Funcion que devuelve la serie de pasos para el jackpot.
     * @param n (int) numero de ruedas
     * @return Matriz de enteros con los movimientos realizados [rueda, giros].
     */
    public static int[][] solve(int n) throws SlotMachineException {
        if (currentMachine == null) {
            currentMachine = new SlotMachine(n);
        }

        totalActions = 0;
        List<int[]> moves = new ArrayList<>();

        if (currentMachine.distinctSymbols() == 1) {
            return listToArray(moves);
        }
        
        if (step1(moves, n)) {
            return listToArray(moves);
        }

        int[] next = new int[n + 1];
        
        if (step2(moves, n, next)) {
            return listToArray(moves);
        }
        
        step3(moves, n, next);
          
        return listToArray(moves);
    }

    /**
     * Fase 1: deja todas las ruedas mostrando simbolos distintos, maximizando k rueda por rueda.
     * @param moves lista donde se registran los movimientos realizados
     * @param n numero de ruedas
     * @return true si se alcanzo el jackpot durante esta fase
     */
    private static boolean step1(List<int[]> moves, int n) throws SlotMachineException {
        int k = currentMachine.distinctSymbols();
        for (int wheel = 2; wheel <= n && totalActions < MAX_ACTIONS; wheel++) {
            int bestK = k;
            int bestPos = 0;

            for (int pos = 1; pos < n && totalActions < MAX_ACTIONS; pos++) {
                spinWheel(wheel, 1, moves);
                k = currentMachine.distinctSymbols();

                if (k == 1) {
                    return true;
                }

                if (k > bestK) {
                    bestK = k;
                    bestPos = pos;

                }
            }

            int stepsToBest = (bestPos + 1) % n;
            if (stepsToBest > 0 && totalActions < MAX_ACTIONS) {
                spinWheel(wheel, stepsToBest, moves);
                k = currentMachine.distinctSymbols();

                if (k == 1) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Fase 2: encuentra el sucesor de cada rueda en el circulo oculto, probando pares (i, j)
     * y deshaciendo siempre el movimiento de prueba (exito o fracaso).
     * @param moves lista donde se registran los movimientos realizados
     * @param n numero de ruedas
     * @param next arreglo de salida: next[i] = rueda sucesora de i
     * @return true si se alcanzo el jackpot durante esta fase
     */
    private static boolean step2(List<int[]> moves, int n, int[] next) throws SlotMachineException {
        boolean[] hasnext = new boolean[n + 1];
        boolean[] foundTail = new boolean[n + 1];
        for (int i = 1; i <= n && totalActions < MAX_ACTIONS; i++) {
            for (int j = 1; j <= n && totalActions < MAX_ACTIONS; j++) {
                if (i == j || foundTail[j]) continue;

                spinWheel(i, 1, moves);
                if (currentMachine.distinctSymbols() == 1) {
                    return true;
                }

                spinWheel(j, -1, moves);
                int k = currentMachine.distinctSymbols();
                if (k == 1) {
                    return true;
                }

                if (k == n) {
                    next[i] = j;
                    hasnext[i] = true;
                    foundTail[j] = true;
                }

                spinWheel(i, -1, moves);
                spinWheel(j, 1, moves);

                if (hasnext[i]) {
                    break;
                }
            }
        }
        return false;
    }

    /**
     * Fase 3: usando el orden circular hallado en step2, alinea todas las ruedas
     * respecto a la rueda 1 (que no se mueve).
     * @param moves lista donde se registran los movimientos realizados
     * @param n numero de ruedas
     * @param next arreglo con el sucesor de cada rueda, calculado en step2
     */
    private static void step3(List<int[]> moves, int n, int[] next) throws SlotMachineException {
        int[] jumpsReference = new int[n + 1];
        int actual = 1;
        int jumps = 0;

        for (int contador = 0; contador < n; contador++) {
            jumpsReference[actual] = jumps;
            actual = next[actual];
            jumps++;
        }

        for (int wheel = 2; wheel <= n && totalActions < MAX_ACTIONS; wheel++) {
            int shift = -jumpsReference[wheel];
            if (shift != 0) {
                spinWheel(wheel, shift, moves);
            }
        }
    }

    /**
     * Ejecuta el giro en la maquina, incrementa el contador global de acciones
     * y registra el movimiento realizado.
     */
    private static void spinWheel(int wheel, int steps, List<int[]> moves) throws SlotMachineException {
        currentMachine.spin(wheel, steps);
        totalActions++;
        moves.add(new int[]{wheel, steps});
    }

    /**
     * @param moves (List<int[]>) Nos da la lista de movimientos para el jackpot
     * @return Retorna un arreglo de arreglos de enteros
     */
    private static int[][] listToArray(List<int[]> moves) {
        return moves.toArray(new int[0][]);
    }

    /**
     * @param n (int) Nos da el numero de ruedas y simbolos
     * Muestra la simulacion.
     */
    public static void simulate(int n) throws SlotMachineException {
        currentMachine = new SlotMachine(n);
        currentMachine.makeVisible();
        solve(n);
    }
}