import java.util.ArrayList;
/**
 * Write a description of class Lefty here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Lefty extends Wheel{
    /**
     * Constructor para instanciar un nuevo Symbol.
     * 
     * @param color identificador del color (ej. "red", "blue", "yellow")
     * @param forma tipo de figura geométrica ("Triangle", "Circle", "Rectangle")
     */
    public Lefty(ArrayList<Symbol> symbols){
        super(symbols);
        border.changeColor("green");
    } 
    

    protected void doSpin(ArrayList<Symbol> symbols, Wheel left) {
        if (left != null && left.getActualSymbol() != null) {
            setSymbol(left.getActualSymbol());   // setSymbol hace copy(): conserva tipo y estado
        } else {
            super.doSpin(symbols, left);         // sin vecina, gira normal
        }
    }
    
    @Override 
    protected String defaultBorderColor() { return "green"; }
    
}