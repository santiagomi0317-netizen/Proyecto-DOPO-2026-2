
/**
 * Write a description of class Normal here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NormalS extends Symbol{
    /**
     * Constructor para instanciar un nuevo Symbol.
     * 
     * @param color identificador del color (ej. "red", "blue", "yellow")
     * @param forma tipo de figura geométrica ("Triangle", "Circle", "Rectangle")
     */
    public NormalS(String color, String forma){
        super(color, forma);
    } 
    
    @Override
    protected void onSelected(){
        return;
    }
    
    @Override
    protected void onSpin(){
        return;
    }
    
    @Override
    public Symbol copy() { 
        return new NormalS(getColor(), getForm());
    }
}