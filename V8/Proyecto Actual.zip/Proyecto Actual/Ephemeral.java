
/**
 * Write a description of class Ephemeral here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ephemeral extends Symbol{
    private static final int INITIAL_SIZE = 30;
    private static final int STEP = 5;
    private static final int MIN_SIZE = 1;   
    private int size;
    
    public Ephemeral(String color, String forma) {
        this(color, forma, INITIAL_SIZE);
    }

    private Ephemeral(String color, String forma, int size) {
        super(color, forma);
        this.size = size;
        if (size != INITIAL_SIZE && getFigure() != null) {
            getFigure().resize(size);   
        }
    }
    
    @Override
    public void onSpin() {
        size = Math.max(MIN_SIZE, size - STEP);
        if (getFigure() != null) getFigure().resize(size);
    }
    
     /**
     * @return el tamaño actual en píxeles
     */
    public int getSize() {
        return size;
    }
    
    @Override
    protected void onSelected(){
        return;
    }
    
    @Override
    public Symbol copy() { 
        return new Ephemeral(getColor(), getForm(), size); 
    }
}