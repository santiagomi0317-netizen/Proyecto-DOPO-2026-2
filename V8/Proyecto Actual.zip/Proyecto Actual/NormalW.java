import java.util.ArrayList;

/**
 * Write a description of class Normal here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NormalW extends Wheel{
    /**
     * Constructor para instanciar un nuevo Symbol.
     * 
     * @param color identificador del color (ej. "red", "blue", "yellow")
     * @param forma tipo de figura geométrica ("Triangle", "Circle", "Rectangle")
     */
    public NormalW(ArrayList<Symbol> symbols){
        super(symbols);
    } 
    
    @Override 
    protected String defaultBorderColor() { return "black"; }
}