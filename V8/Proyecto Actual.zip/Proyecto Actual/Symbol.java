import javax.swing.JOptionPane;
import java.util.Random;

/**
 * Clase que se encarga de crear lo symbolos de ActualSymbol en mis wheels
 * 
 * @author (Santiago Murillo) 
 * @version (12 de septiembre)
 */
public abstract class Symbol {
    protected String color;
    protected String forma;
    protected boolean isVisible;
    protected boolean shown;
    protected Figure figure;
    protected static String[] figuras = {"triangle", "circle", "rectangle"};
    
    /**
     * Constructor para instanciar un nuevo Symbol.
     * 
     * @param color identificador del color (ej. "red", "blue", "yellow")
     * @param forma tipo de figura geométrica ("Triangle", "Circle", "Rectangle")
     */
    // Invariante: Un objeto Symbol válido siempre se inicializa de forma oculta (isVisible = false)
    // y con la figura gráfica correspondiente instanciada si el color es válido según el estándar CSS.
    public Symbol(String color, String forma) {
        String cssColor = validColor.colorExists(color);
        if (cssColor != null) {
            this.color = cssColor;
            if (forma != null && !forma.trim().isEmpty()) {
                this.forma = forma.trim().toLowerCase();
            } else {
                Random random = new Random();
                int randomIndex = random.nextInt(figuras.length);
                this.forma = figuras[randomIndex];
            }
            this.isVisible = false;
            createFigure(this.color, this.forma);
        } else {
            //.showMessageDialog(null, "Color no válido según el estándar CSS", "Error", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    /**
     * Obtiene el color identificador del símbolo.
     * 
     * @return el nombre o código del color
     */
    // Invariante: Devuelve siempre la representación en cadena de texto del color asignado al símbolo.
    public String getColor() {
        return this.color;
    }
    
    /**
     * Obtiene el tipo de forma geométrica del símbolo.
     * 
     * @return el nombre de la figura geométrica
     */
    // Invariante: Devuelve siempre la cadena de texto con la forma geométrica en minúsculas asignada al símbolo.
    public String getForm() {
        return this.forma;
    }
    
    /**
     * Oculta la figura del símbolo de la pantalla.
     */
    // Invariante: Cambia la visibilidad interna a false e invoca el ocultamiento en el objeto 
    //gráfico correspondiente (circulo, rectangulo o triangulo).
    public void makeInvisible() {
        this.isVisible = false;
        if (figure != null) figure.makeInvisible();
    }
    
    /**
     * Muestra la figura del símbolo de la pantalla.
     */
    // Invariante: Cambia la visibilidad interna a true e invoca la visualización en el objeto gráfico correspondiente.
    public void makeVisible() {
        this.isVisible = true;
        if (figure != null) figure.makeVisible();
    }
    
    /**
     * Desplaza horizontalmente la figura visual para alinearla en su columna.
     * 
     * @param distance Cantidad de píxeles a desplazar.
     */
    // Invariante: Aplica un desplazamiento horizontal exactamente de la cantidad de píxeles
    //indicada sobre la figura gráfica asociada que no sea nula.
    public void moveHorizontal(int distance) {
        if (figure != null) figure.moveHorizontal(distance);
    }

    /**
     * Desplaza verticalmente la figura visual en la pantalla.
     * 
     * @param distance cantidad de píxeles a mover en el eje Y
     */
    // Invariante: Aplica un desplazamiento vertical exactamente de la cantidad de píxeles 
    //indicada sobre la figura gráfica asociada que no sea nula.
    public void moveVertical(int distance) {
        if (figure != null) figure.moveVertical(distance);
    }  
    
    /**
     * Crea la figura correspondiente según el valor de 'forma' y le aplica el color.
     * @param color (String)
     * @param forma (String)
     */
    // Invariante: Instancia únicamente el tipo de objeto geométrico ("circle", "rectangle" o "triangle")
    //especificado por 'forma', aplicándole el color ingresado y ajustando su desplazamiento base.
    private void createFigure(String color, String forma) {
        switch (forma) {
            case "circle":
                figure = new Circle();
                break;
            case "rectangle":
                figure = new Rectangle();
                break;
            case "triangle":
                figure = new Triangle();
                break;
        }
        figure.changeColor(color);
        figure.moveHorizontal(10); 
        figure.moveVertical(10);
    }
    
    protected Figure getFigure() {
        return this.figure;
    }
    
    protected abstract void onSpin();
    
    protected abstract void onSelected();
    
    public abstract Symbol copy();
    
    protected void show() {
        isVisible = true;
        if (figure != null) figure.makeVisible();
    }
    
    protected void hide() {
        isVisible = false;
        if (figure != null) figure.makeInvisible();
    }
}