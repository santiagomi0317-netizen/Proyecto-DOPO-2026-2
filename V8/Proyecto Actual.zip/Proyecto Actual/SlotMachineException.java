/**
* Clase implemntada para manejar las excepciones de SlotMachine
*/

public class SlotMachineException extends Exception {
    public static final String W = "A machine could not move north";

    public SlotMachineException(String message) {
        super(message);
    }
}