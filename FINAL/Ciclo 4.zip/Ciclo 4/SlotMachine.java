import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.util.Random;
import java.util.Arrays;

/**
 * Clase principal de la maquina traga monedas
 * Reutiliza el paquete "shapes" (a través de Wheel) para el dibujo.
 * 
 * @author (Santiago Murillo) 
 * Coordina un conjunto de ruedas (Wheel), simbolos (Symbol) y la interfaz grafica
 * <p> Tipos de ruedas</p>
 * <ol>
 *  <li>Borde negro -> normal
 *  <li>Borde verde -> lefty
 *  <li>Borde naranja -> Rebel
 *  <li>Borde amarillo -> Teleport
 *  <li>Borde rojo -> Bloqueada
 * </ol>
 * <p> Colores en el borde de la SlotMachine</p>
 * <ol>
 *  <li>Borde negro -> No hay Jackpot
 *  <li>Borde azul -> Jackpot
 * </ol>
 * @version (12 de septiembre)
 */
public class SlotMachine {
    private ArrayList<Wheel> wheels;
    private ArrayList<Symbol> symbols;
    private boolean isVisible;
    private boolean ok;
    private RectangleBorder generalBorder;
    private static String[] forms = {"triangle", "circle", "rectangle"};
    private static String[] colors = {    
            "aquamarine", "bisque", "black", "blue", "blueviolet", "brown", "burlywood",
            "cadetblue", "chartreuse", "chocolate", "coral", "cornflowerblue", "crimson", "cyan",
            "darkblue", "darkcyan", "darkgoldenrod", "darkgrey", "darkgreen", "darkkhaki",
            "darkmagenta", "darkolivegreen", "darkorange", "darkorchid", "darkred", "darksalmon",
            "darkseagreen", "darkslateblue", "darkslategrey", "darkturquoise", "darkviolet",
            "deeppink", "deepskyblue", "dimgrey", "dodgerblue", "firebrick", "forestgreen",
            "fuchsia", "gainsboro", "gold", "goldenrod", "grey", "green", "greenyellow",
            "hotpink", "indianred", "indigo", "khaki", "lawngreen", "lightblue", "lightcoral",
            "lightgrey", "lightgreen", "lightpink", "lightsalmon", "lightseagreen", "lightskyblue",
            "lightslategrey", "lightsteelblue", "lime", "limegreen", "maroon", "mediumaquamarine",
            "mediumblue", "mediumorchid", "mediumpurple", "mediumseagreen", "mediumslateblue",
            "mediumspringgreen", "mediumturquoise", "mediumvioletred", "midnightblue", "mistyrose",
            "moccasin", "navajowhite", "navy", "olive", "olivedrab", "orange", "orangered",
            "orchid", "palegoldenrod", "palegreen", "paleturquoise", "palevioletred", "peachpuff",
            "peru", "pink", "plum", "powderblue", "purple", "rebeccapurple", "red", "rosybrown",
            "royalblue", "saddlebrown", "salmon", "sandybrown", "seagreen", "sienna", "silver",
            "skyblue", "slateblue", "slategrey", "springgreen", "steelblue", "tan", "teal",
            "thistle", "tomato", "turquoise", "violet", "wheat", "yellow", "yellowgreen"};
    private static String[] symboltype = {"normal","shy", "ephemeral"};
    private static String[] wheeltype = {"normal","rebel", "lefty", "teleport"};

    /**
     * Creador el cual crea una maquina con cero simbolos y ruedas
     */
    public SlotMachine() {
        wheels = new ArrayList<Wheel>();
        symbols = new ArrayList<Symbol>();
        isVisible = false;
        
        generalBorder = new RectangleBorder(200, 80, 2, "black");
        generalBorder.moveHorizontal(20);
        generalBorder.moveVertical(20);
    }
    
    
    /**
     * Sobrecarga del creador una maquina con 3 wheels e indica si es visible o no
     * @param vis (boolean) que me indica si se quiere comenzar visible la maquina
     * @throws SlotMachineException si falla la creación de los símbolos o ruedas iniciales
     * (no debería ocurrir con los valores por defecto, pero se propaga lo que lancen
     *  addSymbol y addWheel)
     */
    // Invariante: siempre cuando creamos una maquina , esta es visible siemrpe y cuando se cumpla vis , viene con tres ruedas, 
    //con un borde que abarca las ruedas, una lista de tres ruedas y simbolos.
    public SlotMachine(boolean vis) throws SlotMachineException {
        wheels = new ArrayList<Wheel>();
        symbols = new ArrayList<Symbol>();
        isVisible = vis;
        
        generalBorder = new RectangleBorder(200, 80, 2, "black");
        generalBorder.moveHorizontal(20);
        generalBorder.moveVertical(20);

        for (int i=0; i<3 ;i++){
            addSymbol(colors[i],"",symboltype[i]);
        }
        
        for (int i=0; i<4 ;i++){
            addWheel(wheeltype[i], wheels.size() + 1);
        }
    }
    
    /**
     * Sobre carga de contructor con un parametro entero que me da mismo numero de ruedas que simbolos
     * @param nwheels (int) crea tanta cantidad de ruedas comom de simbolos con ul limite 30, porque no cabe en pantanlla
     * @throws SlotMachineException MINIUM_WHEELS si nwheels es menor que 3,
     * MAX_WHEELS si nwheels es 51 o más,
     * o cualquier error propagado desde addSymbol y addMultipleWheels
     */
    // Invariante: siempre cuando creamos una maquina , esta es visible, viene con nwheels ruedas-simbolos, 
    // con un borde que abarca las ruedas.
    public SlotMachine(int nwheels) throws SlotMachineException {
        if (nwheels < 3) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.MINIUM_WHEELS);
        }
        if (nwheels>=51) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.MAX_WHEELS);
        }
        
        wheels = new ArrayList<Wheel>();
        symbols = new ArrayList<Symbol>();
        isVisible = false;

        generalBorder = new RectangleBorder(200, 80, 2, "black");
        generalBorder.moveHorizontal(20);
        generalBorder.moveVertical(20);
        
        
        for (int i=0; i< nwheels ;i++){
            addSymbol(colors[i],"");
        } 
        addMultipleWheels(nwheels, "");

    } 
    
    /**
     * Agrega una rueda normal en la nueva en la posición indicada
     * @param pos (int) posición donde se insertará la rueda (1-based)
     * @throws SlotMachineException EMPTY_SYMBOLS si el catálogo no tiene símbolos
     * (propagada desde addWheel(String, int))
     */
    // Invariante: Siempre indexo uan rueda, si int es negativo la indexo al principio
    // si es superior a el tamaño de wheels al final
    public void addWheel(int pos) throws SlotMachineException {
        addWheel("normal", pos);
    }
    
    /**
     * Agrega una rueda nueva en la posición indicada del tipo indicado, o si el tipo es vacio nulo normal.
     * @param type (String) tipo de rueda ("normal", "lefty", "rebel", "teleport")
     * @param pos (int) posición donde se insertará la rueda (1-based)
     * @throws SlotMachineException EMPTY_SYMBOLS si el catálogo no tiene símbolos,
     * WHEEL_NOT_IN_TYPE si el tipo de rueda no existe
     */
    // Invariante: Siempre indexo uan rueda, si int es negativo la indexo al principio
    // si es superior a el tamaño de wheels al final
    public void addWheel(String type, int pos) throws SlotMachineException {
        if (symbols == null || symbols.isEmpty()){
            ok = false;
            throw new SlotMachineException(SlotMachineException.EMPTY_SYMBOLS);
        }
        Wheel nueva = createWheel(type);
        if (nueva == null) { 
            ok = false;
            throw new SlotMachineException(SlotMachineException.WHEEL_NOT_IN_TYPE);
        }
        int index = Math.max(0, Math.min(pos - 1, wheels.size()));
        wheels.add(index, nueva);
        if (isVisible) nueva.makeVisible();
        reorderVisualWheels();
        syncNeighbors();
        checkJackpot();
    }
    
    /**
     * Elige el tipo de rueda y la crea
     * @param  type (String) tipo de rueda
     * @return Wheel, devuelve la rueda ya instanciada, o null si el tipo no existe
     * @throws SlotMachineException propagada desde el constructor de Wheel
     * (por ejemplo, si el catálogo de símbolos está vacío)
     */
    private Wheel createWheel(String type) throws SlotMachineException {
        String t = (type == null || type.trim().isEmpty()) ? "normal" : type.trim().toLowerCase();
        switch (t) {
            case "normal": return new NormalW(symbols);
            case "lefty":  return new Lefty(symbols);
            case "rebel":  return new Rebel(symbols);
            case "teleport": return new Teleport(symbols);
            default:       return null;
        }
    }    
       
    /**
     * Elimina la rueda en la posición dada (1-pos).
     * @param pos (int) posición de la rueda a eliminar
     * @throws SlotMachineException MINIUM_WHEELS si hay 3 ruedas o menos,
     * INDEX_OUT_OF_BOUNDS si pos no corresponde a una rueda,
     * REBEL_TYPE si la rueda es rebelde y no se puede eliminar.
     */
    // Invariante, siempre tiene que haber 3 ruedas funcionales en la maquina tragamonedas, 
    // si se intenta eliminar una para quedar con dos no se puede realizar la accion
    public void delWheel(int pos) throws SlotMachineException {
        if (wheels.size() <= 3) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.MINIUM_WHEELS);
        }
        if (pos < 1 || pos > wheels.size()) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.INDEX_OUT_OF_BOUNDS);
        }
        if (!wheelAt(pos).canDelete()) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.REBEL_TYPE);
        }
        
        Wheel wheelToRemove = wheels.remove(pos - 1);
        wheelToRemove.makeInvisible();
        reorderVisualWheels();
        syncNeighbors();
        checkJackpot();
        ok = true;
    }
    
    /**
     * Añade un símbolo al catálogo de la máquina del tipo normal
     * @param color (String) identificador único del símbolo, basado en el estandas css
     * @param forma (String) figura geométrica ("Triangle", "Circle", "Rectangle")
     * @throws SlotMachineException las mismas que addSymbol(String, String, String)
     */
    // Invariante, se agrega un simbolo si su color no se encuentra en la lista Symbols y cumple es estadnar CSS
    public void addSymbol(String color, String forma) throws SlotMachineException {
        addSymbol(color, forma, "normal");
    }
      
    /**
     * Añade un símbolo al catálogo de la máquina dado un tipo, si este es vacio o nulo seria normal
     * @param color (String) identificador único del símbolo, basado en el estandas css
     * @param forma (String) figura geométrica ("Triangle", "Circle", "Rectangle")
     * @param type (String) tipo de símbolo ("normal", "shy", "ephemeral")
     * @throws SlotMachineException NULL_COLOR si el color es nulo o vacío,
     * CSS_COLOR si el color no cumple el estándar CSS,
     * REPEAT_COLOR si ya existe un símbolo con ese color,
     * WRONG_FORM si la forma no es circle, rectangle o triangle,
     * WRONG_TYPE si el tipo de símbolo no existe
     */
    // Invariante, se agrega un simbolo si su color no se encuentra en la lista Symbols y cumple es estadnar CSS
    public void addSymbol(String color, String forma, String type) throws SlotMachineException {
        if (color == null || color.isEmpty()) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.NULL_COLOR);
        }
        String colorCSS = validColor.colorExists(color.trim().toLowerCase());
        if (colorCSS == null) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.CSS_COLOR);
        }
        if (findSymbol(colorCSS) != null) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.REPEAT_COLOR);
        }
        String formaFormat = randomForm(forma);
        if (formaFormat == null) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.WRONG_FORM);
        }
        Symbol nueva = createSymbol(colorCSS, formaFormat , type);
        if (nueva == null) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.WRONG_TYPE);
        }
        symbols.add(nueva);
        ok = true;
    } 
    
    /**
     * Cuando la forma es nula o vacia se elige random la forma entre tres, si forma tiene una cdena esta se evalau si es aceptada
     * @param forma (String) referencia al forma que tendra el simbolo
     * @return String, null si no lo cumple, en el caso favorecido la forma del simbolo a instanciar
     */
    private String randomForm(String forma){
        if (forma == null || forma.trim().isEmpty()) {
            Random random = new Random();
            return forms[random.nextInt(forms.length)];
        }
        
        String formaFormat = forma.trim().toLowerCase();
        if (formaFormat.equals("circle") || formaFormat.equals("rectangle") || formaFormat.equals("triangle")) {
            return formaFormat;
        }
        return null;
    }
    
    
    /**
     * Instancia el simbolo teniendo en cuenta el tipo
     * @param colorCSS String, color que cumple estandares CSS
     * @param forma String, color que cumple estandares 
     * @param type String, tipo de simbolo
     * @return Symbol, devuelve el simbolo instanciado si la forma cumple los estandares, de lo contrario null.
     */
    private Symbol createSymbol(String colorCSS, String forma, String type) {
        String t = (type == null || type.trim().isEmpty()) ? "normal" : type.trim().toLowerCase();
        switch (t) {
            case "normal":
                return new NormalS(colorCSS, forma);
            case "shy":
                return new Shy(colorCSS, forma, false);
            case "ephemeral":
                return new Ephemeral(colorCSS, forma);
            default:
                return null;
        }
    } 

    /**
     * Elimina un símbolo de la máquina por su color
     * @param color (String) del símbolo a quitar
     * @throws SlotMachineException NULL_SYMBOL si el símbolo no existe en el catálogo,
     *         ACTUAL_SYMBOL_ON_LOCKED_WHEEL si una rueda bloqueada lo está mostrando
     */
    // Invariante, se elimina un symbolo el cual su id(color) existe en la lista symbols
    public void delSymbol(String color) throws SlotMachineException {
        Symbol found = findSymbol(color);
        
        if (found == null) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.NULL_SYMBOL);
        }
    
        // Si una rueda bloqueada lo muestra, no se puede cambiar: se rechaza
        for (Wheel wheel : wheels) {
            if (wheel.isLocked() && found.getColor().equals(wheel.getColor())) {
                ok = false;
                throw new SlotMachineException(SlotMachineException.ACTUAL_SYMBOL_ON_LOCKED_WHEEL);     
            }
        }
        symbols.remove(found);
        
        for (int i = 0; i < wheels.size(); i++) {
            Wheel wheel = wheels.get(i);
            if (found.getColor().equals(wheel.getColor())) {
                if (symbols.isEmpty()) {
                    wheel.setSymbol(null);
                } else {
                    Wheel left = (i > 0) ? wheels.get(i - 1) : null;
                    wheel.spin(symbols, left);
                }
            }
        }
        checkJackpot();
        ok = true;
    }
    
    /**
     * Establece el símbolo seleccionado en la rueda indicada
     * @param wheelPos(int) posición de la rueda (1-based)
     * @param color(String) id del símbolo
     * @throws SlotMachineException SYMBOL_NOT_FOUND si el color no está en el catálogo,
     * LOCKED_WHEEL si la rueda destino está bloqueada
     */
    // Invariante, mi wheelPos en un negativa,
    // la indexo al principio y si es superior al tamaño la pongo en la ultima. 
    // Por otro lado cuando el simbolo no se encuentra en my lista symbols, 
    // no se puede realizar la accion
    public void placeSymbol(int wheelPos, String color) throws SlotMachineException {
        Symbol symbolToPlace = findSymbol(color);
        if (symbolToPlace == null) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.SYMBOL_NOT_FOUND);
        }
        
        Wheel targetWheel = wheelAt(wheelPos);
        
        if (targetWheel.isLocked()){
            ok = false;
            throw new SlotMachineException(SlotMachineException.LOCKED_WHEEL); 
        }
        
        targetWheel.setSymbol(symbolToPlace); 
        syncNeighbors();
        checkJackpot();
        ok = true;       
    }
        
    /**
     * Rueda una rueda específica
     * @param wheelPos (int) posición de la rueda (1-based)
     * Sobrecarga de spin donde recibe un parametro int
     * @throws SlotMachineException NULL_WHEEL si la rueda no existe,
     * EMPTY_SYMBOLS si no hay símbolos,
     * LOCKED_WHEEL si la rueda está bloqueada,
     * o un error propagado desde teleport
    */
    // Invariante, si la rueda no existe o no hay simbolos que colocar no se realiza
    // la accion
    public void spin(int wheelPos) throws SlotMachineException {
        Wheel wheel = wheelAt(wheelPos);
        if (wheel == null ) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.NULL_WHEEL);
        }
        if (symbols.isEmpty()) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.EMPTY_SYMBOLS);
        }
        if (wheel.isLocked()) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.LOCKED_WHEEL);
        }
        
        wheel.spin(symbols, wheelAt(wheelPos - 1));  
        if (wheel.teleports()) teleport(wheel);
        syncNeighbors();
        checkJackpot();
        ok = true;
    }
    
    /**
     * Rueda todas las ruedas de la máquina
     * Sobrecarga de spin donde no recibe nada
     * @throws SlotMachineException EMPTY_SYMBOLS si no hay símbolos,
     * o un error propagado desde teleport
     */
    // Invriante, si no tengo ningun elemento en la lista de Symbols, no puedo girar
    public void spin() throws SlotMachineException {
        if (symbols.isEmpty()) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.EMPTY_SYMBOLS);
        }
        
        for (Wheel w : new ArrayList<Wheel>(wheels)) {
            if (w.teleports() && !w.isLocked()) teleport(w);
        }
        
        for (int i = 0; i < wheels.size(); i++) {
            Wheel left = (i > 0) ? wheels.get(i - 1) : null;
            wheels.get(i).spin(symbols, left);
        }
        
        checkJackpot();
        ok = true;
    }
    
    /**
     * Se realiza intercambio de la rueda de Tipo teleport
     * @param w Wheel, rueda de tipo Teleport
     * @throws SlotMachineException propagada desde swap (no debería ocurrir,
     * porque solo se eligen como destino ruedas que pueden intercambiarse)
     */
    private void teleport(Wheel w) throws SlotMachineException {
        int from = foundPos(w);
        if (from == -1) return;
        ArrayList<Integer> candidates = new ArrayList<Integer>();
        for (int j = 0; j < wheels.size(); j++) {
            if (j != from && wheels.get(j).canSwap()) {
                candidates.add(j);
            }
        }
        if (candidates.isEmpty()) return;   // todas las demás son rebel
    
        int to = candidates.get(new Random().nextInt(candidates.size()));
        swap(from + 1, to + 1);
        reorderVisualWheels();
    }
    
    /**
     * Busca la posicion de una rueda en el catalogo
     * @param w Wheel, rueda a encontrar
     * @return int, la posicion si se encuentra en el catalogo, de lo contrario -1
     */    
    private int foundPos(Wheel w) {
        for(Wheel wheel: wheels){
            if (wheel.equals(w)){
                return  wheels.indexOf(w);
            }
        }
        return -1;
    }
    
    /**
     * Retorna los símbolos del catálogo
     * @return arreglo (String[]) con los colores disponibles
     */
    public String[] symbols() {
        if (symbols.isEmpty()) {
            ok = true;
            return new String[0];
        }
        
        String[] result = new String[symbols.size()];
        for (int i = 0; i < symbols.size(); i++) {
            result[i] = symbols.get(i).getColor();
        }
        ok = true;
        return result;
    }
    
    /**
     * Retorna los colores de los símbolos visibles actualmente
     * @return arreglo con los colores de cada rueda
     */
    public String[] configuration() {
        if (wheels.isEmpty()) {
            ok = true;
            return new String[0];
        }
        
        String[] result = new String[wheels.size()];
        for (int i = 0; i < wheels.size(); i++) {
            result[i] = wheels.get(i).getColor();
        }
        ok = true;
        return result;
    }
    
    /**
     * Retorna el número de distintos colores visibles
     * @return cantidad de colores únicos en las ruedas (int)
     */
    public int distinctSymbols() {
        ArrayList<String> distinct = new ArrayList<>();
        for (String color : configuration()) {
            if (color != null && !distinct.contains(color)) {
                distinct.add(color);
            }
        }
        ok = true;
        return distinct.size();
    }
    
    /**
     * Evalúa si todas las ruedas muestran el mismo símbolo
     * @return boolean
     */
    // Invariante, true si es jackpot; false en caso contrario
    public boolean isJackpot(){
        if (distinctSymbols() != 1 || wheels.size()<=2) {
            ok = true;
            return false;
        }
        ok = true;
        return true;
        
    }
    
    /**
     * Oculta la máquina en pantalla
     */
    public void makeInvisible() {
        isVisible = false;
        for (Wheel wheel : wheels) {
            wheel.makeInvisible();
        }
        if (generalBorder != null) {
            generalBorder.makeInvisible();
            ok = true;
        }
    }

    /**
     * Hace visible la máquina en pantalla
     */
    public void makeVisible() {
        isVisible = true;
        if (generalBorder != null) {
            generalBorder.makeVisible();
        }
        for (Wheel wheel : wheels) {
            wheel.makeVisible();
        }
        ok = true;
    }  
    
    /**
     * Termina la simulación ocultando
     */
    public void exit() {
        makeInvisible();
        ok = true;
    }
    
    /**
     * Indica el estado de la última acción realizada
     * @return bolean
     */
    public boolean ok() {
        return ok;
    }
    
    /**
     * Agrega tantas ruedas al final de mi maquina
     * @param num (int) cantidad de ruedas a agregar
     * @param type (String) tipo de las ruedas
     * @throws SlotMachineException EMPTY_SYMBOLS o WHEEL_NOT_IN_TYPE propagadas desde addWheel.
     * Si falla a mitad, las ruedas ya agregadas se conservan
     */
    // Invariante, siempre voy a crear tantas ruedas como me indique el usuario siguendo las restricciones de addWheel
    public void addMultipleWheels(int num, String type) throws SlotMachineException {
        for (int i=0; i<num; i++){
            addWheel(type, wheels.size() + 1);
        }
    }
    
    /**
     * Quita tantas ruedas al final de mi maquina
     * @param num (int) cantidad de ruedas a eliminar
     * @throws SlotMachineException MINIUM_WHEELS, INDEX_OUT_OF_BOUNDS o REBEL_TYPE
     * propagadas desde delWheel. Si falla a mitad, las ruedas ya eliminadas
     * no se restauran
     */
    // Invariante, siempre voy a eliminar tantas ruedas como me indique el usuario, 
    // siguendo las restricciones de delWheel
    public void delMultipleWheels(int num) throws SlotMachineException{
        for (int i=0; i<num; i++){
            delWheel(wheels.size());
        }
    }
    
    /**
     * Obtiene la rueda en la posición especificada (1-based)
     * @param wheelPos posición de la rueda 
     * @return el objeto Wheel si la posición es válida; null en caso contrario.
     */
    // Invariante, al encontrar la rueda dentro de mi arreglo de Wheels, devuelvo la
    // posicion -1 para que lo entienda la maquina
    public Wheel wheelAt(int pos) {
        if (pos < 1 || pos > wheels.size()) {
            return null;
        }
        return wheels.get(pos - 1);
    }
    
    /**
     * Busca un símbolo en la lista por su color.
     * @param color (String) identificador del símbolo
     * @return el Symbol (Symbol) encontrado o null si no existe
     */
    private Symbol findSymbol(String color) {
        if (color == null) {
            return null; 
        }
        for (Symbol s : symbols) {
            if (s.getColor() != null && s.getColor().equalsIgnoreCase(color)) {
                return s;
            }
        }
        return null;
    } 

    /**
     * Dado dos ruedas les cambio la posicion en mi ArrayList de wheels
     * @param wheel1 (int) posicion de la rueda numero 1 en wheels
     * @param wheel2 (int) posicion de la rueda numero 1 en wheels
     * @throws SlotMachineException INDEX_OUT_OF_BOUNDS si alguna posición no existe,
     * SAME_WHEELS si ambas posiciones son iguales,
     * REBEL_TYPE si alguna de las ruedas no se puede intercambiar
     */
    // Invariante: Siempre que las dos ruedas existan en mi ArrayList de wheels, estas se cambian.
    public void swap(int wheel1,int wheel2) throws SlotMachineException { 
        if (wheel1 < 1 || wheel1 > wheels.size() || wheel2 < 1 || wheel2 > wheels.size()) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.INDEX_OUT_OF_BOUNDS);
        }
        if (wheel1==wheel2) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.SAME_WHEELS);
        }
        Wheel target1 = wheelAt(wheel1);
        Wheel target2 = wheelAt(wheel2);
        
        if (!target1.canSwap() || !target2.canSwap() ) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.REBEL_TYPE);
        }
        
        wheels.set(wheel1 - 1, target2);
        wheels.set(wheel2 - 1, target1);
        reorderVisualWheels();
        syncNeighbors();
        checkJackpot();
        ok=true;
    }
    
    /**
     * Dada una rueda se le bloquea por medio de un metodo llamado lock en Wheel
     * @param wheel1 (int) posicion de la rueda numero en wheels
     * @throws SlotMachineException NULL_WHEEL si la rueda no existe.
     * Si la rueda existe pero no se puede bloquear, no lanza excepción:
     * deja ok = false y termina
     */
    // Invariante: Siempre que exista la rueda en wheels, se le modificara el atributo lock
    public void lock(int wheel) throws SlotMachineException { 
        if (wheel < 1 || wheel > wheels.size()) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.NULL_WHEEL);
        }
        Wheel target = wheels.get(wheel - 1);
        if (!target.canLock()) { 
            ok = false;
            return; 
        }
        target.lock();
        ok = true;
    }
    
    /**
     * Dada una rueda se le bloquea por medio de un metodo llamado unlock en Wheel 
     * @param wheel1 (int) posicion de la rueda numero en wheels
     * @throws SlotMachineException NULL_WHEEL si la rueda no existe
     */
    // Invariante: Siempre que exista la rueda en wheels, se le modificara el atributo lock
    public void unlock(int wheel) throws SlotMachineException{ 
        if (wheel < 1 || wheel > wheels.size()) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.NULL_WHEEL);
        } 
        wheels.get(wheel - 1).unlock();
        syncNeighbors();
        ok = true;
    }
    
    /**
     * Dado la posicion de la rueda en mi ArrayList la voy a mover tantos steps en mi ArrayList symbols
     * Se debe mostrar como si fuera una ruleta mostrando symbolo por symbolo hasta llegar al final
     * @param wheel1 (int) posicion de la rueda numero en wheels
     * @param steps (int) cantidad de cambios de posciones que se debe spinear mi rueda
     * @throws SlotMachineException NULL_WHEEL si la rueda no existe,
     * EMPTY_SYMBOLS si no hay símbolos,
     * LOCKED_WHEEL si la rueda está bloqueada.
     * Si steps es 0 no hace nada y no lanza excepción
     */
    // Invariante: Siempre que exista la rueda en wheels, se realiza un spin mostrando 
    // paso a paso cada uno de los simbolos de mi ArrayList Symbols
    public void spin(int wheel, int steps) throws SlotMachineException {
        if (steps == 0) {
            return;
        }
        if (wheel < 1 || wheel > wheels.size() ) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.NULL_WHEEL); 
        }
        if (symbols == null || symbols.isEmpty()) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.EMPTY_SYMBOLS);
        }
        Wheel w = wheelAt(wheel);
        if (w.isLocked()){
            ok = false;
            throw new SlotMachineException(SlotMachineException.LOCKED_WHEEL); 
        } 
        
        w.stepSpin(symbols, steps);
        syncNeighbors();
        checkJackpot();
        ok=true;
    }   

    /**
     * Dado un arreglo de Strings(Cada posicion debe contener un String que se refiera al color del symbol a colocar
     * @param symbolstoput (String[]) el cual nos da la configuracion que quiere el usuario en la maquina actual.
     * @throws SlotMachineException CONFIGURATION_ARRAY_WEIRD si el arreglo es null,
     * si el catálogo está vacío o si su tamaño no coincide con el número de ruedas
     */
    // Invariante: Si la cadena cumple con los requisitos previos, esta se convierte en la configuracion actual de la SlotMachine
    public void spin(String[] symbolstoput) throws SlotMachineException {
        if (symbolstoput == null || symbols == null || symbols.isEmpty() ||symbolstoput.length != wheels.size()) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.CONFIGURATION_ARRAY_WEIRD); 
        } 
        
        for (int i=0; i<wheels.size();i++){
            Wheel w = wheels.get(i);
            if (w.isLocked()) continue;
            String aimColor = symbolstoput[i];
            Symbol aimSymbol = findSymbol(aimColor);
            if (aimSymbol != null){
                w.setSymbol(aimSymbol);
                if (this.isVisible) {
                    w.makeVisible();
                }   
            }
        }
        checkJackpot();
        ok = true;
    }
    
    /**
     * Dado un arreglo cada posicion debe contener un String que se refiera al color del symbol a adicionar el el catalogo de simbolos
     * @param symbolstoput (String[]) el cual nos da la configuracion que quiere el usuario en la maquina actual.
     * @throws SlotMachineException CONFIGURATION_ARRAY_WEIRD si el arreglo es null,
     * o cualquier error propagado desde addSymbol.
     * Los símbolos agregados antes del fallo se conservan
     */
    // Invariante: Agrega un arreglo de símbolos al catálogo de la máquina
    public void addSymbol(String[] symbolstoput) throws SlotMachineException {
        if (symbolstoput == null) {
            ok = false;
            throw new SlotMachineException(SlotMachineException.CONFIGURATION_ARRAY_WEIRD);
        } 
        
        for (int i=0; i<symbolstoput.length;i++) {
            addSymbol(symbolstoput[i],"","");  
        }
    }
    
    /**
     * Formatea una posicion para retornar su indice correspondiente
     * @param pos (int) dado una posicion contando desde uno
     * @return index (int) posicion formateada
     */
    // Invariante: Siempre me devuelve el indice correcto 
    private int formatPos(int pos){
        if (pos < 1) {
            return 0;
        } else if (pos > wheels.size()) {
            return wheels.size() - 1;
        }
        return pos - 1;
    }
    
    /**
     * Reorganiza las posiciones XY de cada rueda para mantener una separación consistente.
     */
    // Tomada de Gemini
    // Invariante: Reordena visualmente la posición X de todas las ruedas en pantalla 
    //ajusta dinámicamente el ancho del borde general para cubrir el número total de ruedas.
    private void reorderVisualWheels() {
        int margenInicialX = 35;
        int margenInicialY = 35;
        int espaciadoX = 60;
        int espaciadoY = 80;
        int columnasPorFila = 21;
    
        // Coordenada exacta fija donde DEBE iniciar la esquina superior izquierda del borde
        int targetX = margenInicialX -15;
        int targetY = margenInicialY + 20; // 20 unidades más abajo de la primera fila
    
        if (wheels.size() <= columnasPorFila) {
            // Acomodar ruedas en la primera fila (1 a 30)
            for (int i = 0; i < wheels.size(); i++) {
                wheels.get(i).moveA(margenInicialX + (i * espaciadoX), margenInicialY);
            }
    
            if (generalBorder != null) {
                int anchoCalculado = (wheels.size() * espaciadoX) + 20;
    
                // Ajustar únicamente las dimensiones (el origen top-left se mantiene inmóvil)
                generalBorder.changeSize(anchoCalculado, 80);
    
                // Corregir la posición únicamente si la esquina superior no coincide exactamente con targetX, targetY
                int diffX = targetX - generalBorder.getPositionX();
                int diffY = targetY - generalBorder.getPositionY();
    
                if (diffX != 0) generalBorder.moveHorizontal(diffX);
                if (diffY != 0) generalBorder.moveVertical(diffY);
    
                if (isVisible) {
                    generalBorder.makeVisible();
                }
            }
        } else {
            // Acomodar ruedas en cuadrícula al superar 30
            for (int i = 0; i < wheels.size(); i++) {
                int fila = i / columnasPorFila;
                int columna = i % columnasPorFila;
    
                int posX = margenInicialX + (columna * espaciadoX);
                int posY = margenInicialY + (fila * espaciadoY);
    
                wheels.get(i).moveA(posX, posY);
            }
    
            if (generalBorder != null) {
                int totalFilas = (int) Math.ceil((double) wheels.size() / columnasPorFila);
                int anchoFijo = (columnasPorFila * espaciadoX) + 20;
                int altoCalculado = (totalFilas * espaciadoY);
    
                // Expandir marco en Y manteniendo ancho fijo
                generalBorder.changeSize(anchoFijo, altoCalculado);
    
                int diffX = targetX - generalBorder.getPositionX();
                int diffY = targetY - generalBorder.getPositionY();
    
                if (diffX != 0) generalBorder.moveHorizontal(diffX);
                if (diffY != 0) generalBorder.moveVertical(diffY);
    
                if (isVisible) {
                    generalBorder.makeVisible();
                }
            }
        }
    }
    
    /**
     * Interfaz que muestra al usuario si actuamnente hay un Jackpot
     */
    private void checkJackpot() {
        if (isJackpot() && isVisible) {
            JOptionPane.showMessageDialog(null, "Ganaste", "Información", JOptionPane.INFORMATION_MESSAGE);
            generalBorder.changeColor("blue");
        } else {
            generalBorder.changeColor("black");
        }
    }
    
    /**
     * Obtiene el simbolo en la posición especificada (1-based)
     * @param pos posición del simbolo 
     * @return el objeto Symbol si la posición es válida; null en caso contrario.
     */
    // Invariante, al encontrar la rueda dentro de mi arreglo de Wheels, devuelvo la
    // posicion -1 para que lo entienda la maquina
    public Symbol symbolAt(int pos) {
        if (pos < 1 || pos > symbols.size()) {
            return null;
        }
        return symbols.get(pos - 1);
    }
    
    /**
     * Despues de que se realice un giro, confirma que las ruedas de tipo Lefty cumplan su invariante
     */
    private void syncNeighbors() {
        for (int i = 0; i < wheels.size(); i++) {
            Wheel left = (i > 0) ? wheels.get(i - 1) : null;
            wheels.get(i).onNeighborChanged(left);
        }
    }
}