public class Shy extends Symbol{
    private boolean hidden;

    public Shy(String color, String forma) {
        this(color, forma, false);
    }

    private Shy(String color, String forma, boolean hidden) {
        super(color, forma);
        this.hidden = hidden;
    }

    @Override
    public void makeVisible() {
        shown = true;
        if (!hidden) show();
    }

    @Override
    public void onSelected() {
        hidden = !hidden;
        if (hidden) {
            hide();
        } else if (shown){
             show();
        }
    }
    
    public boolean isHidden() { 
        return hidden; 
    }
    
    @Override
    protected void onSpin(){
        return;
    }

    @Override
    public Symbol copy() { 
        return new Shy(getColor(), getForm(), hidden); 
    }
}