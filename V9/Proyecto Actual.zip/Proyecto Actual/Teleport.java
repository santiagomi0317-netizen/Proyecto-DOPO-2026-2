import java.util.ArrayList;
/**
 * Write a description of class Lefty here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Teleport extends Wheel{
    /**
     * Constructor para instanciar un nuevo Symbol.
     * 
     * @param color identificador del color (ej. "red", "blue", "yellow")
     * @param forma tipo de figura geométrica ("Triangle", "Circle", "Rectangle")
     */
    public Teleport(ArrayList<Symbol> symbols) throws SlotMachineException {
        super(symbols);
        border.changeColor("yellow");
    } 
    
    @Override 
    public boolean teleports() { return true; }
    
    @Override 
    protected String defaultBorderColor() { return "yellow"; }
}