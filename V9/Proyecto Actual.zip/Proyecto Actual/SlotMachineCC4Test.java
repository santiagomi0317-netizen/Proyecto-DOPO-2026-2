import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Pruebas de unidad del ciclo 4: tipos de rueda (normal, rebel, lefty, teleport)
 * y tipos de símbolo (normal, shy, ephemeral).
 *
 * Supuestos: new SlotMachine() crea una máquina vacía e invisible,
 * wheelAt y symbolAt usan posiciones desde 1, y la clase del símbolo normal es NormalS.
 * addWheel exige un catálogo con al menos un símbolo (si no, lanza EMPTY_SYMBOLS).
 *
 * @author Santiago Murillo
 * @version 4.0
 * Implementado con IA
 */
public class SlotMachineCC4Test {
    private SlotMachine machine;

    /**
     * Crea una máquina vacía e invisible antes de cada prueba.
     */
    @BeforeEach
    public void setUp() {
        machine = new SlotMachine();
    }

    /**
     * Libera los recursos después de cada prueba.
     */
    @AfterEach
    public void tearDown() {
        machine = null;
    }

    /**
     * Agrega tres símbolos al catálogo: red, blue y green.
     */
    private void fillCatalog() throws SlotMachineException {
        machine.addSymbol("red", "circle");
        machine.addSymbol("blue", "circle");
        machine.addSymbol("green", "circle");
    }

    /**
     * ¿Qué debería hacer? Conservar su símbolo si está bloqueada, aunque la vecina cambie.
     * ¿Qué no debería hacer? Copiar a la vecina mientras está bloqueada.
     */
    @Test
    public void lockedLeftyWheelDoesNotCopy() throws SlotMachineException {
        fillCatalog();
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        machine.placeSymbol(2, "blue");
        machine.lock(2);
        machine.placeSymbol(1, "red");
        for (int i = 0; i < 10; i++) machine.spin();
        assertEquals("blue", machine.configuration()[1]);
    }

    /**
     * ¿Qué debería hacer? Mostrar el símbolo de su nueva vecina inmediatamente después de un swap.
     * ¿Qué no debería hacer? Quedarse con el símbolo de su antigua vecina.
     * (Requiere syncNeighbors en swap.)
     */
    @Test
    public void leftyWheelCopiesNewNeighborAfterSwap() throws SlotMachineException {
        machine.addSymbol("red", "circle");
        machine.addSymbol("blue", "circle");
        machine.addWheel("normal", 1);
        machine.addWheel("normal", 2);
        machine.addWheel("lefty", 3);
        machine.placeSymbol(1, "red");
        machine.placeSymbol(2, "blue");
        machine.swap(2, 3);
        String[] c = machine.configuration();
        assertEquals(c[0], c[1]);
    }
}