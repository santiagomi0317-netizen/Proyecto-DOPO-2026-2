import java.util.ArrayList;
/**
 * Write a description of class rebel here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Rebel extends Wheel{
    /**
     * Constructor para instanciar un nuevo Symbol.
     * 
     * @param color identificador del color (ej. "red", "blue", "yellow")
     * @param forma tipo de figura geométrica ("Triangle", "Circle", "Rectangle")
     */
    public Rebel(ArrayList<Symbol> symbols) throws SlotMachineException {
        super(symbols);
        border.changeColor("orange");
    } 
    
    @Override public boolean canLock()   { return false; }
    @Override public boolean canSwap()   { return false; }
    @Override public boolean canDelete() { return false; }
    
    @Override 
    protected String defaultBorderColor() { return "orange"; }
}