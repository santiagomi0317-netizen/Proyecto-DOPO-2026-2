import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.util.Random;

/**
 * Clase principal de la maquina traga monedas
 * Reutiliza el paquete "shapes" (a través de Wheel) para el dibujo.
 * 
 * @author (Santiago Murillo) 
 * Coordina un conjunto de ruedas (Wheel), simbolos (Symbol) y la interfaz grafica
 * @version (12 de septiembre)
 */
public class SlotMachine {
    private ArrayList<Wheel> wheels;
    private ArrayList<Symbol> symbols;
    private boolean isVisible;
    private boolean ok;
    private RectangleBorder generalBorder;
    private String[] colors;

    /**
     * Creador el cual crea una maquina con 3 wheels
     */
    //Invariante: siempre cuando creamos una maquina , esta es visible, viene con tres ruedas, 
    //con un borde que abarca las ruedas, una lista de tres ruedas y simbolos.
    public SlotMachine() {
        wheels = new ArrayList<Wheel>();
        symbols = new ArrayList<Symbol>();
        isVisible = true;
        colors = new String[] {    
            "aquamarine", "bisque", "black", "blue", "blueviolet", "brown", "burlywood",
            "cadetblue", "chartreuse", "chocolate", "coral", "cornflowerblue", "crimson", "cyan",
            "darkblue", "darkcyan", "darkgoldenrod", "darkgrey", "darkgreen", "darkkhaki",
            "darkmagenta", "darkolivegreen", "darkorange", "darkorchid", "darkred", "darksalmon",
            "darkseagreen", "darkslateblue", "darkslategrey", "darkturquoise", "darkviolet",
            "deeppink", "deepskyblue", "dimgrey", "dodgerblue", "firebrick", "forestgreen",
            "fuchsia", "gainsboro", "gold", "goldenrod", "grey", "green", "greenyellow",
            "hotpink", "indianred", "indigo", "khaki", "lawngreen", "lightblue", "lightcoral",
            "lightgrey", "lightgreen", "lightpink", "lightsalmon", "lightseagreen", "lightskyblue",
            "lightslategrey", "lightsteelblue", "lime", "limegreen", "maroon", "mediumaquamarine",
            "mediumblue", "mediumorchid", "mediumpurple", "mediumseagreen", "mediumslateblue",
            "mediumspringgreen", "mediumturquoise", "mediumvioletred", "midnightblue", "mistyrose",
            "moccasin", "navajowhite", "navy", "olive", "olivedrab", "orange", "orangered",
            "orchid", "palegoldenrod", "palegreen", "paleturquoise", "palevioletred", "peachpuff",
            "peru", "pink", "plum", "powderblue", "purple", "rebeccapurple", "red", "rosybrown",
            "royalblue", "saddlebrown", "salmon", "sandybrown", "seagreen", "sienna", "silver",
            "skyblue", "slateblue", "slategrey", "springgreen", "steelblue", "tan", "teal",
            "thistle", "tomato", "turquoise", "violet", "wheat", "yellow", "yellowgreen"
        };
        generalBorder = new RectangleBorder(200, 80, 2, "black");
        generalBorder.moveHorizontal(20);
        generalBorder.moveVertical(20);
        

        for (int i=0; i<3 ;i++){
            addSymbol(colors[i],"");
        }
        addMultipleWheels(3);

        if (isJackpot() && isVisible) {
            JOptionPane.showMessageDialog(null, "Ganaste", "Información", JOptionPane.INFORMATION_MESSAGE);
            generalBorder.changeColor("blue");
            ok = true;
        } else {
            generalBorder.changeColor("black");
        }
    }
    
    /**
     * Sobrecarga del creador una maquina con 3 wheels 
     * @param vis (boolean) que me indica si se quiere comenzar visible la maquina
     */
    // Invariante: siempre cuando creamos una maquina , esta es visible siemrpe y cuando se cumpla vis , viene con tres ruedas, 
    //con un borde que abarca las ruedas, una lista de tres ruedas y simbolos.
    public SlotMachine(boolean vis) {
        wheels = new ArrayList<Wheel>();
        symbols = new ArrayList<Symbol>();
        isVisible = vis;
        colors = new String[] {
            "aquamarine", "bisque", "black", "blue", "blueviolet", "brown", "burlywood",
            "cadetblue", "chartreuse", "chocolate", "coral", "cornflowerblue", "crimson", "cyan",
            "darkblue", "darkcyan", "darkgoldenrod", "darkgrey", "darkgreen", "darkkhaki",
            "darkmagenta", "darkolivegreen", "darkorange", "darkorchid", "darkred", "darksalmon",
            "darkseagreen", "darkslateblue", "darkslategrey", "darkturquoise", "darkviolet",
            "deeppink", "deepskyblue", "dimgrey", "dodgerblue", "firebrick", "forestgreen",
            "fuchsia", "gainsboro", "gold", "goldenrod", "grey", "green", "greenyellow",
            "hotpink", "indianred", "indigo", "khaki", "lawngreen", "lightblue", "lightcoral",
            "lightgrey", "lightgreen", "lightpink", "lightsalmon", "lightseagreen", "lightskyblue",
            "lightslategrey", "lightsteelblue", "lime", "limegreen", "maroon", "mediumaquamarine",
            "mediumblue", "mediumorchid", "mediumpurple", "mediumseagreen", "mediumslateblue",
            "mediumspringgreen", "mediumturquoise", "mediumvioletred", "midnightblue", "mistyrose",
            "moccasin", "navajowhite", "navy", "olive", "olivedrab", "orange", "orangered",
            "orchid", "palegoldenrod", "palegreen", "paleturquoise", "palevioletred", "peachpuff",
            "peru", "pink", "plum", "powderblue", "purple", "rebeccapurple", "red", "rosybrown",
            "royalblue", "saddlebrown", "salmon", "sandybrown", "seagreen", "sienna", "silver",
            "skyblue", "slateblue", "slategrey", "springgreen", "steelblue", "tan", "teal",
            "thistle", "tomato", "turquoise", "violet", "wheat", "yellow", "yellowgreen"
        };
        
        generalBorder = new RectangleBorder(200, 80, 2, "black");
        generalBorder.moveHorizontal(20);
        generalBorder.moveVertical(20);

        for (int i=0; i<3 ;i++){
            addSymbol(colors[i],"");
        } 
        addMultipleWheels(3);

        if (isJackpot() && isVisible) {
            JOptionPane.showMessageDialog(null, "Ganaste", "Información", JOptionPane.INFORMATION_MESSAGE);
            generalBorder.changeColor("blue");
            ok = true;
        } else {
            generalBorder.changeColor("black");
        }
    }
    
    /**
     * Sobre carga de contructor con un parametro entero
     * @param nwheels (int) crea tanta cantidad de ruedas comom de simbolos con ul limite 30, porque no cabe en pantanlla
     */
    // Invariante: siempre cuando creamos una maquina , esta es visible, viene con nwheels ruedas-simbolos, 
    // con un borde que abarca las ruedas.
    public SlotMachine(int nwheels) {
        if (2>nwheels) {
            JOptionPane.showMessageDialog(null, "Ruedas insuficientes", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (nwheels>=51) {
            JOptionPane.showMessageDialog(null, "Ruedas exceden la cantidad de colores", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        wheels = new ArrayList<Wheel>();
        symbols = new ArrayList<Symbol>();
        isVisible = false;
        colors = new String[] {
            "aquamarine", "bisque", "black", "blue", "blueviolet", "brown", "burlywood",
            "cadetblue", "chartreuse", "chocolate", "coral", "cornflowerblue", "crimson", "cyan",
            "darkblue", "darkcyan", "darkgoldenrod", "darkgrey", "darkgreen", "darkkhaki",
            "darkmagenta", "darkolivegreen", "darkorange", "darkorchid", "darkred", "darksalmon",
            "darkseagreen", "darkslateblue", "darkslategrey", "darkturquoise", "darkviolet",
            "deeppink", "deepskyblue", "dimgrey", "dodgerblue", "firebrick", "forestgreen",
            "fuchsia", "gainsboro", "gold", "goldenrod", "grey", "green", "greenyellow",
            "hotpink", "indianred", "indigo", "khaki", "lawngreen", "lightblue",
        };

        generalBorder = new RectangleBorder(200, 80, 2, "black");
        generalBorder.moveHorizontal(20);
        generalBorder.moveVertical(20);
        
        
        for (int i=0; i< nwheels ;i++){
            addSymbol(colors[i],"");
        } 
        addMultipleWheels(nwheels);
                
        if (isJackpot() && isVisible) {
            JOptionPane.showMessageDialog(null, "Ganaste", "Información", JOptionPane.INFORMATION_MESSAGE);
            generalBorder.changeColor("blue");
            ok = true;
        } else {
            generalBorder.changeColor("black");
        }
    } 
    
    /**
     * Agrega una rueda nueva en la posición indicada
     * @param pos (int) posición donde se insertará la rueda (1-based)
     */
    // Invariante: Siempre indexo uan rueda, si int es negativo la indexo al principio
    // si es superior a el tamaño de wheels al final
    public void addWheel(int pos) {
        int index= formatPos(pos);

        Wheel nueva = new Wheel(symbols);
        wheels.add(index, nueva);
        reorderVisualWheels();
        
        if (isVisible) nueva.makeVisible();
        if (isJackpot() && isVisible) {
            JOptionPane.showMessageDialog(null, "Ganaste", "Información", JOptionPane.INFORMATION_MESSAGE);
            generalBorder.changeColor("blue");
            ok = true;
        } else {
            generalBorder.changeColor("black");
        }
    }
    
    /**
     * Elimina la rueda en la posición dada (1-pos).
     * @param pos (int) posición de la rueda a eliminar
     */
    // Invariante, siempre tiene que haber 3 ruedas funcionales en la maquina tragamonedas, 
    // si se intenta eliminar una para quedar con dos no se puede realizar la accion
    public void delWheel(int pos) {
        if (wheels.size() <= 3) {
            //JOptionPane.showMessageDialog(null, "No se puede eliminar: Mínimo debe haber 3 ruedas", "Error", JOptionPane.ERROR_MESSAGE);
            ok = false;
            return;
        }
        if (pos < 1 || pos > wheels.size()) {
            //JOptionPane.showMessageDialog(null, "Posición de rueda inválida", "Error", JOptionPane.ERROR_MESSAGE);
            ok = false;
            return;
        }
        
        Wheel wheelToRemove = wheels.remove(pos - 1);
        wheelToRemove.makeInvisible();
        
        reorderVisualWheels();
        if (isJackpot() && isVisible) {
            JOptionPane.showMessageDialog(null, "Ganaste", "Información", JOptionPane.INFORMATION_MESSAGE);
            generalBorder.changeColor("blue");
            ok = true;
        } else {
            generalBorder.changeColor("black");
        }
        ok = true;
    }
      
    /**
     * Añade un símbolo al catálogo de la máquina
     * @param color (String) identificador único del símbolo, basado en el estandas css
     * @param forma (String) figura geométrica ("Triangle", "Circle", "Rectangle")
     */
    // Invariante, se agrega un simbolo si su color no se encuentra en la lista Symbols y cumple es estadnar CSS
    public void addSymbol(String color, String forma) {
        if (color == null || color.isEmpty()) {
            ok = false;
            //JOptionPane.showMessageDialog(null, "El color no puede estar vacio.", "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String colorCSS = validColor.colorExists(color.trim().toLowerCase());
        if (colorCSS == null) {
            ok = false; 
            //JOptionPane.showMessageDialog(null, "Simbolo no cumple con los estandare CSS" + " " + color, "Error", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if (findSymbol(colorCSS) != null) {
            ok = false; 
            //JOptionPane.showMessageDialog(null, "Simbolo ya creado" + " " + color, "Error", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        Symbol newSymbol = new Symbol(color, forma);
        symbols.add(newSymbol);
        ok = true;
    } 

    /**
     * Elimina un símbolo de la máquina por su color
     * @param color (String) del símbolo a quitar
     */
    // Invariante, se elimina un symbolo el cual su id(color) existe en la lista symbols
    public void delSymbol(String color) {
        Symbol found = findSymbol(color);
        
        if (found == null) {
            //JOptionPane.showMessageDialog(null, "Símbolo no encontrado", "Error", JOptionPane.ERROR_MESSAGE);
            ok = false;
            return;
        }
    
        // Si una rueda tenía este símbolo, la hace girar para cambiarlo
        for (Wheel wheel : wheels) {
            while (wheel.getActualSymbol() == found) {
                wheel.spin(symbols);
            }
        }
        symbols.remove(found);
        ok = true;
    }
    
    /**
     * Establece el símbolo seleccionado en la rueda indicada
     * @param wheelPos(int) posición de la rueda (1-based)
     * @param color(String) id del símbolo
     */
    // Invariante, mi wheelPos en un negativa,
    // la indexo al principio y si es superior al tamaño la pongo en la ultima. 
    // Por otro lado cuando el simbolo no se encuentra en my lista symbols, 
    // no se puede realizar la accion
    public void placeSymbol(int wheelPos, String color) {
        Symbol symbolToPlace = findSymbol(color);
        if (symbolToPlace == null) {
            //JOptionPane.showMessageDialog(null, "Símbolo no encontrado", "Error", JOptionPane.ERROR_MESSAGE);
            ok = false;
            return;
        }
        int index = formatPos(wheelPos);
        Wheel targetWheel = wheels.get(index);
        if (targetWheel.isLocked()){
            ok = false;
            //JOptionPane.showMessageDialog(null, "Rueda bloqueada", "Error", JOptionPane.ERROR_MESSAGE);
            return; 
        }
        targetWheel.setSymbol(symbolToPlace); 
        if (isJackpot() && isVisible) {
            JOptionPane.showMessageDialog(null, "Ganaste", "Información", JOptionPane.INFORMATION_MESSAGE);
            generalBorder.changeColor("blue");
            ok = true;
        } else {
            generalBorder.changeColor("black");
        }
        ok = true;       
    }
        
    /**
     * Rueda una rueda específica
     * @param wheelPos (int) posición de la rueda (1-based)
     * Sobrecarga de spin donde recibe un parametro int
    */
    // Invariante, si la rueda no existe o no hay simbolos que colocar no se realiza
    // la accion
    public void spin(int wheelPos) {
        Wheel wheel = wheelAt(wheelPos);
        if (wheel == null || symbols.isEmpty()) {
            //JOptionPane.showMessageDialog(null, "Rueda no existe o catálogo de símbolos vacío", "Error", JOptionPane.ERROR_MESSAGE);
            ok = false;
            return;
        }
        if (wheel.isLocked()) {
            ok = false;
            //JOptionPane.showMessageDialog(null, "Rueda bloqueada", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        wheel.spin(symbols);
        if (isJackpot() && isVisible) {
            JOptionPane.showMessageDialog(null, "Ganaste", "Información", JOptionPane.INFORMATION_MESSAGE);
            generalBorder.changeColor("blue");
            ok = true;
        } else {
            generalBorder.changeColor("black");
        }
        ok = true;
    }
    
    /**
     * Rueda todas las ruedas de la máquina
     * Sobrecarga de spin donde no recibe nada
     */
    // Invriante, si no tengo ningun elemento en la lista de Symbols, no puedo girar
    public void spin() {
        if (symbols.isEmpty()) {
            //JOptionPane.showMessageDialog(null, "No hay símbolos configurados para girar", "Error", JOptionPane.ERROR_MESSAGE);
            ok = false;
            return;
        }
        for (Wheel wheel : wheels) {
            wheel.spin(symbols);
        }
        if (isJackpot() && isVisible) {
            JOptionPane.showMessageDialog(null, "Ganaste", "Información", JOptionPane.INFORMATION_MESSAGE);
            generalBorder.changeColor("blue");
            ok = true;
        } else {
            generalBorder.changeColor("black");
        }
        ok = true;
    }
    
    /**
     * Retorna los símbolos del catálogo
     * @return arreglo (String[]) con los colores disponibles
     */
    public String[] symbols() {
        if (symbols.isEmpty()) {
            ok = true;
            return new String[0];
        }
        
        String[] result = new String[symbols.size()];
        for (int i = 0; i < symbols.size(); i++) {
            result[i] = symbols.get(i).getColor();
        }
        ok = true;
        return result;
    }
    
    /**
     * Retorna los colores de los símbolos visibles actualmente
     * @return arreglo con los colores de cada rueda
     */
    public String[] configuration() {
        if (wheels.isEmpty()) {
            ok = true;
            return new String[0];
        }
        
        String[] result = new String[wheels.size()];
        for (int i = 0; i < wheels.size(); i++) {
            result[i] = wheels.get(i).getColor();
        }
        ok = true;
        return result;
    }
    
    /**
     * Retorna el número de distintos colores visibles
     * @return cantidad de colores únicos en las ruedas (int)
     */
    public int distinctSymbols() {
        ArrayList<String> distinct = new ArrayList<>();
        for (String color : configuration()) {
            if (color != null && !distinct.contains(color)) {
                distinct.add(color);
            }
        }
        ok = true;
        return distinct.size();
    }
    
    /**
     * Evalúa si todas las ruedas muestran el mismo símbolo
     * @return boolean
     */
    // Invariante, true si es jackpot; false en caso contrario
    public boolean isJackpot(){
        if (distinctSymbols() != 1 || wheels.size()<=2) {
            ok = true;
            return false;
        }
        ok = true;
        return true;
        
    }
    
    /**
     * Oculta la máquina en pantalla
     */
    public void makeInvisible() {
        isVisible = false;
        for (Wheel wheel : wheels) {
            wheel.makeInvisible();
        }
        if (generalBorder != null) {
            generalBorder.makeInvisible();
            ok = true;
        }
    }

    /**
     * Hace visible la máquina en pantalla
     */
    public void makeVisible() {
        isVisible = true;
        if (generalBorder != null) {
            generalBorder.makeVisible();
        }
        for (Wheel wheel : wheels) {
            wheel.makeVisible();
        }
        ok = true;
    }  
    
    /**
     * Termina la simulación ocultando
     */
    public void exit() {
        makeInvisible();
        ok = true;
    }
    
    /**
     * Indica el estado de la última acción realizada
     * @return bolean
     */
    public boolean ok() {
        return ok;
    }
    
    /**
     * Agrega tantas ruedas al final de mi maquina
     */
    // Invariante, siempre voy a crear tantas ruedas como me indique el usuario siguendo las restricciones de addWheel
    public void addMultipleWheels(int num) {
        for (int i=0; i<num; i++){
            addWheel(wheels.size()+1);
        }
    }
    
    /**
     * Quita tantas ruedas al final de mi maquina
     */
    // Invariante, siempre voy a eliminar tantas ruedas como me indique el usuario, 
    // siguendo las restricciones de delWheel
    public void delMultipleWheels(int num) {
        for (int i=0; i<num; i++){
            delWheel(wheels.size());
        }
    }
    
    /**
     * Obtiene la rueda en la posición especificada (1-based)
     * @param wheelPos posición de la rueda 
     * @return el objeto Wheel si la posición es válida; null en caso contrario.
     */
    // Invariante, al encontrar la rueda dentro de mi arreglo de Wheels, devuelvo la
    // posicion -1 para que lo entienda la maquina
    public Wheel wheelAt(int pos) {
        if (pos < 1 || pos > wheels.size()) {
            return null;
        }
        return wheels.get(pos - 1);
    }
    
    /**
     * Busca un símbolo en la lista por su color.
     * @param color (String) identificador del símbolo
     * @return el Symbol (Symbol) encontrado o null si no existe
     */
    public Symbol findSymbol(String color) {
        if (color == null) {
            return null; 
        }
        for (Symbol s : symbols) {
            if (s.getColor() != null && s.getColor().equalsIgnoreCase(color)) {
                return s;
            }
        }
        return null;
    } 

    /**
     * Dado dos ruedas les cambio la posicion en mi ArrayList de wheels
     * @param wheel1 (int) posicion de la rueda numero 1 en wheels
     * @param wheel2 (int) posicion de la rueda numero 1 en wheels
     */
    // Invariante: Siempre que las dos ruedas existan en mi ArrayList de wheels, estas se cambian.
    public void swap(int wheel1,int wheel2){ 
        if (wheel1 < 1 || wheel1 > wheels.size() || wheel2 < 1 || wheel2 > wheels.size() || wheel1==wheel2) {
            ok = false;
            //JOptionPane.showMessageDialog(null, "Rueda o ruedas no cumplen las condiciones", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int index1 = wheel1 - 1;
        int index2 = wheel2 - 1;
        
        Wheel w = wheels.get(index1);
        wheels.set(index1, wheels.get(index2));
        wheels.set(index2, w);
        
        reorderVisualWheels();
        ok=true;
    }
    
    /**
     * Dada una rueda se le bloquea por medio de un metodo llamado lock en Wheel
     * @param wheel1 (int) posicion de la rueda numero en wheels
     */
    // Invariante: Siempre que exista la rueda en wheels, se le modificara el atributo lock
    public void lock(int wheel){ 
        if (wheel < 1 || wheel > wheels.size()) {
            ok = false;
            //JOptionPane.showMessageDialog(null, "Rueda no existe", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        wheels.get(wheel - 1).lock();
        ok = true;
    }
    
    /**
     * Dada una rueda se le bloquea por medio de un metodo llamado unlock en Wheel 
     * @param wheel1 (int) posicion de la rueda numero en wheels
     */
    // Invariante: Siempre que exista la rueda en wheels, se le modificara el atributo lock
    public void unlock(int wheel){ 
        if (wheel < 1 || wheel > wheels.size()) {
            ok = false;
            //JOptionPane.showMessageDialog(null, "Rueda no existe", "Error", JOptionPane.INFORMATION_MESSAGE);
            return;
        } 
        wheels.get(wheel - 1).unlock();
        ok = true;
    }
    
    /**
     * Dado la posicion de la rueda en mi ArrayList la voy a mover tantos steps en mi ArrayList symbols
     * Se debe mostrar como si fuera una ruleta mostrando symbolo por symbolo hasta llegar al final
     * @param wheel1 (int) posicion de la rueda numero en wheels
     * @param steps (int) cantidad de cambios de posciones que se debe spinear mi rueda
     */
    // Invariante: Siempre que exista la rueda en wheels, se realiza un spin mostrando 
    // paso a paso cada uno de los simbolos de mi ArrayList Symbols
    public void spin(int wheel, int steps){
        if (wheel < 1 || wheel > wheels.size() || symbols == null || symbols.isEmpty()) {
            //JOptionPane.showMessageDialog(null, "Rueda no existe o no hay símbolos", "Error", JOptionPane.ERROR_MESSAGE);
            ok = false;
            return; 
        }
        Wheel w = wheels.get(wheel - 1);
        if (w.isLocked()){
            ok = false;
            //JOptionPane.showMessageDialog(null, "Rueda bloqueada", "Error", JOptionPane.ERROR_MESSAGE);
            return; 
        } 
        w.stepSpin(symbols, steps);
        if (isJackpot() && isVisible) {
            JOptionPane.showMessageDialog(null, "Ganaste", "Información", JOptionPane.INFORMATION_MESSAGE);
            generalBorder.changeColor("blue");
            ok = true;
        } else {
            generalBorder.changeColor("black");
        }
        ok=true;
    }   

    /**
     * Dado un arreglo de Strings(Cada posicion debe contener un String que se refiera al color del symbol a colocar
     * @param symbolstoput (String[]) el cual nos da la configuracion que quiere el usuario en la maquina actual.
     */
    // Invariante: Si la cadena cumple con los requisitos previos, esta se convierte en la configuracion actual de la SlotMachine
    public void spin(String[] symbolstoput){
        if (symbolstoput == null || symbols == null || symbols.isEmpty() ||symbolstoput.length != wheels.size()) {
            ok = false;
            //JOptionPane.showMessageDialog(null, "Arreglo de configuración incorrecto o no coincide en tamaño", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        } 
        for (int i=0; i<wheels.size();i++){
            Wheel w = wheels.get(i);
            if (w.isLocked()) continue;
            String aimColor = symbolstoput[i];
            Symbol aimSymbol = findSymbol(aimColor);
            if (aimSymbol != null){
                w.setSymbol(aimSymbol);
                if (this.isVisible) {
                    w.makeVisible();
                }   
            }
        }
        if (isJackpot() && isVisible) {
            JOptionPane.showMessageDialog(null, "Ganaste", "Información", JOptionPane.INFORMATION_MESSAGE);
            generalBorder.changeColor("blue");
            ok = true;
        } else {
            generalBorder.changeColor("black");
        }
        ok = true;
    }
    
    /**
     * Dado un arreglo cada posicion debe contener un String que se refiera al color del symbol a adicionar el el catalogo de simbolos
     * @param symbolstoput (String[]) el cual nos da la configuracion que quiere el usuario en la maquina actual.
     */
    // Invariante: Agrega un arreglo de símbolos al catálogo de la máquina
    public void addSymbol(String[] symbolstoput){
        if (symbolstoput == null || symbols.isEmpty()) {
            ok = false;
            //JOptionPane.showMessageDialog(null, "Arreglo de symbolos incorrecto o no coincide en tamaño", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        } 
        for (int i=0; i<symbolstoput.length;i++){
            addSymbol(symbolstoput[i],"");
            if (!ok) {
                ok = false;
            }   
        }
    }
    
    /**
     * Formatea una posicion para retornar su indice correspondiente
     * @param pos (int) dado una posicion contando desde uno
     * @return index (int) posicion formateada
     */
    // Invariante: Siempre me devuelve el indice correcto 
    public int formatPos(int pos){
        int index;
        if (pos < 1) {
            index = 0;
        } else if (pos > wheels.size()) {
            index = wheels.size();
        } else {
            index = pos - 1;
        }
        return index;
    }
    
    
    
    /**
     * Reorganiza las posiciones XY de cada rueda para mantener una separación consistente.
     */
    // Tomada de Gemini
    // Invariante: Reordena visualmente la posición X de todas las ruedas en pantalla 
    //ajusta dinámicamente el ancho del borde general para cubrir el número total de ruedas.
    private void reorderVisualWheels() {
        int margenInicialX = 35;
        int margenInicialY = 35;
        int espaciadoX = 60;
        int espaciadoY = 80;
        int columnasPorFila = 21;
    
        // Coordenada exacta fija donde DEBE iniciar la esquina superior izquierda del borde
        int targetX = margenInicialX -15;
        int targetY = margenInicialY + 20; // 20 unidades más abajo de la primera fila
    
        if (wheels.size() <= columnasPorFila) {
            // Acomodar ruedas en la primera fila (1 a 30)
            for (int i = 0; i < wheels.size(); i++) {
                wheels.get(i).moveA(margenInicialX + (i * espaciadoX), margenInicialY);
            }
    
            if (generalBorder != null) {
                int anchoCalculado = (wheels.size() * espaciadoX) + 20;
    
                // Ajustar únicamente las dimensiones (el origen top-left se mantiene inmóvil)
                generalBorder.changeSize(anchoCalculado, 80);
    
                // Corregir la posición únicamente si la esquina superior no coincide exactamente con targetX, targetY
                int diffX = targetX - generalBorder.getPositionX();
                int diffY = targetY - generalBorder.getPositionY();
    
                if (diffX != 0) generalBorder.moveHorizontal(diffX);
                if (diffY != 0) generalBorder.moveVertical(diffY);
    
                if (isVisible) {
                    generalBorder.makeVisible();
                }
            }
        } else {
            // Acomodar ruedas en cuadrícula al superar 30
            for (int i = 0; i < wheels.size(); i++) {
                int fila = i / columnasPorFila;
                int columna = i % columnasPorFila;
    
                int posX = margenInicialX + (columna * espaciadoX);
                int posY = margenInicialY + (fila * espaciadoY);
    
                wheels.get(i).moveA(posX, posY);
            }
    
            if (generalBorder != null) {
                int totalFilas = (int) Math.ceil((double) wheels.size() / columnasPorFila);
                int anchoFijo = (columnasPorFila * espaciadoX) + 20;
                int altoCalculado = (totalFilas * espaciadoY);
    
                // Expandir marco en Y manteniendo ancho fijo
                generalBorder.changeSize(anchoFijo, altoCalculado);
    
                int diffX = targetX - generalBorder.getPositionX();
                int diffY = targetY - generalBorder.getPositionY();
    
                if (diffX != 0) generalBorder.moveHorizontal(diffX);
                if (diffY != 0) generalBorder.moveVertical(diffY);
    
                if (isVisible) {
                    generalBorder.makeVisible();
                }
            }
        }
    }
}