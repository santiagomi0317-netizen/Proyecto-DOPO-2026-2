import java.util.ArrayList;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 * Clase rueda la cual se encarga de adminsitrar comos e comprta la rueda en acciones como spin
 * 
 * @author (Santiago Murillo) 
 * @version (12 de septiembre)
 */
public class Wheel {
    private Symbol ActualSymbol;
    private boolean isVisible;
    private int positionX;
    private int positionY;
    private RectangleBorder border; 
    private boolean lock;

    /**
     * Constructor de la rueda con un simbolo aleatorio
     * @param symbols (ArrayList<Symbol>) lista de símbolos disponibles
     */
    // Invariante: siempre cuando creamos una rueda, esta inicia no visible, 
    //con posicion en 0, un borde con dimensiones 50x50, desbloqueada y asignando un símbolo aleatorio de la lista dada.
    public Wheel(ArrayList<Symbol> symbols) {
        this.isVisible = false;
        this.positionX = 0;
        this.positionY = 0;
        this.border = new RectangleBorder(50, 50, 1, "black");
        this.border.moveVertical(35);
        this.lock = false;
        if (symbols != null && !symbols.isEmpty()) {
            spin(symbols);
        } else {
            //JOptionPane.showMessageDialog(null, "No hay simbolos para rodar", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Hace girar la rueda y selecciona un símbolo aleatorio de la lista.
     * @param symbols catálogo de símbolos
     * Sobrecarga de Spin que recibe un ArrayList de simbolos
     */
    // Invariante: Solo realiza el giro si la rueda no está bloqueada;
    // si la lista de símbolos es nula o vacía, desasigna el símbolo actual.
    public void spin(ArrayList<Symbol> symbols) {
        if (lock) return;

        if (symbols == null || symbols.isEmpty()) {
            if (this.ActualSymbol != null && isVisible) {
                this.ActualSymbol.makeInvisible();
            }
            this.ActualSymbol = null;
            return;
        }
        Random random = new Random();
        int randomIndex = random.nextInt(symbols.size());
        setSymbol(symbols.get(randomIndex));
    }
    
    /**
     * Tomada de Gemini
     * Reposiciona dinámicamente la rueda y su figura gráfica a las nuevas coordenadas X e Y.
     * @param nuevaPosicionX Coordenada horizontal absoluta.
     * @param nuevaPosicionY Coordenada vertical absoluta.
     */
    // Invariante: Mueve el borde y el símbolo actual horizontal y verticalmente según el desplazamiento calculado y actualiza las coordenadas X e Y.
    public void moveA(int nuevaPosicionX, int nuevaPosicionY) {
        int desplazamientoX = nuevaPosicionX - this.positionX;
        int desplazamientoY = nuevaPosicionY - this.positionY;
        if (this.border != null) {
            this.border.moveHorizontal(desplazamientoX);
            this.border.moveVertical(desplazamientoY);
        }
        if (this.ActualSymbol != null) {
            this.ActualSymbol.moveHorizontal(desplazamientoX);
            this.ActualSymbol.moveVertical(desplazamientoY);
        }

        this.positionX = nuevaPosicionX;
        this.positionY = nuevaPosicionY;
    }
    
    /**
     * Asigna un símbolo específico a la rueda.
     * @param symbol nuevo símbolo a mostrar
     */
    // Invariante: Reemplaza el símbolo actual haciendo invisible el anterior y posicionando 
    //el nuevo según las coordenadas horizontales y verticales de la rueda.
    public void setSymbol(Symbol symbol) {
        if (this.ActualSymbol != null) {
            this.ActualSymbol.makeInvisible();
        }
        if (symbol != null) {
            this.ActualSymbol = new Symbol(symbol.getColor(), symbol.getForm());
            int targetX = this.positionX;
            int targetY = this.positionY + 35;
            if (targetX != 0) {
                this.ActualSymbol.moveHorizontal(targetX);
            }
            if (targetY != 0) {
                this.ActualSymbol.moveVertical(targetY);
            }
            if (this.isVisible) {
                this.ActualSymbol.makeVisible();
            }
        } else {
            this.ActualSymbol = null;
        }   
    }
    
    /**
     * Retorna el color del símbolo actual o null si no tiene.
     * @return String color del símbolo o null si está vacía la rueda
     */
    // Invariante: Devuelve el identificador de color del objeto ActualSymbol si existe, o nulo si no se ha asignado ningún símbolo.
    public String getColor() {
        if (ActualSymbol != null) {
            return ActualSymbol.getColor();
        } else {
            return null;
        }
    }
    
    /**
     * Retorna el objeto Symbol que está asignado actualmente a la rueda.
     * 
     * @return el Symbol actual, o null si la rueda está vacía.
     */
    // Invariante: Retorna la referencia al objeto Symbol que almacena la rueda actualmente.
    public Symbol getActualSymbol() {
        return this.ActualSymbol;
    }
    
    /**
     * Muestra la rueda visualmente.
     */
    // Invariante: Cambia la visibilidad a true y dibuja en pantalla tanto el símbolo actual como el marco del borde si existen.
    public void makeVisible() {
        this.isVisible = true;
        if (ActualSymbol != null) {
            ActualSymbol.makeVisible();
        }
        if (border != null) {
            border.makeVisible();
        }
    }
    
    /**
     * Oculta la rueda visualmente.
     */
    // Invariante: Cambia la visibilidad a false e oculta en pantalla tanto el símbolo actual como el marco del borde.
    public void makeInvisible() {
        this.isVisible = false;
        if (ActualSymbol != null) {
            ActualSymbol.makeInvisible();
        }
        if (border != null) {
            border.makeInvisible();
        }
    }
    
    /**
     * Bloquea la rueda para evitar que cambie de símbolo en los giros.
     */
    // Invariante: Siempre cuando se bloquea, esta se le ve el marco rojo
    public void lock() {
        this.lock = true;
        if (this.border != null) {
            this.border.changeColor("red");
        }
    }

    /**
     * Desbloquea la rueda permitiendo que vuelva a girar.
    */
    // Invariante: Siempre cuando se bloquea, esta se le ve el marco negro
    public void unlock() {
        this.lock = false;
        if (this.border != null) {
            this.border.changeColor("black");
        }
    }

    /**
     * @return boolean, true si la rueda esta bloqueada o false si esta desbloqueada
    */
    // Invariante: Retorna el estado actual del atributo booleano lock de la rueda.
    public boolean isLocked() {
        return this.lock;
    }
    
    /**
     * Metodo que cambia simbolo por symbolo hasta llegar a el ultimo indicado por steps,
     * Incluye la interfaz grafica
     * @param symbols (ArrayList<Symbol>) lista de simbolos disponibles
     * @param steps (int) cantidad de saltos en symbols
     */
    // Invariante: Siempre que tengamos una lista de symbolos no nula, se van a mostrar uno por uno 
    // en la interfaz grafica como se va recorriendo symbols hasta llegar al simbolo final.
    public void stepSpin(ArrayList<Symbol> symbols, int steps) {
        if (this.lock || symbols.isEmpty() || steps == 0) {
            return;
        }
        int direction;
        if (steps >= 0) {
            direction = 1;
        } else {
            direction = -1;
        }
        int index = findCurrentSymbolIndex(symbols);
        for (int i = 0; i < Math.abs(steps); i++) {
            index += direction;
            if (index >= symbols.size()) {
                index = 0; 
            } else if (index < 0) {
                index = symbols.size() - 1;
            }
            setSymbol(symbols.get(index));
            wait(59);
        }
    }    
    
    /**
    * Método auxiliar para pausar la ejecución unos milisegundos sin bloquear BlueJ.
    * @param miliseconds (int)
    */
    // Invariante: Siempre se para la ejecucion del programa tantos milisegundos como me indique el usuario
    private void wait(int miliseconds) {
        try {
            Thread.sleep(miliseconds);
        } catch (Exception a) {   
        }
    }
    
    /**
     * Método para encontrar la posición del símbolo actual en la lista symbols.
     * @param symbols (ArrayList<Symbol>) lista de simbolos disponibles
     * @return int posición del símbolo actual dentro del ArrayList
     */
    // Invariante: Siempre que el simbolo exista, se obtiene su pocicion en la lista symbols
    public int findCurrentSymbolIndex(ArrayList<Symbol> symbols) {
        if (this.ActualSymbol == null) return 0;
        for (int i = 0; i < symbols.size(); i++) {
            Symbol s = symbols.get(i);
            if (s.getColor().equalsIgnoreCase(this.ActualSymbol.getColor()) &&
                s.getForm().equalsIgnoreCase(this.ActualSymbol.getForm())) {
                return i;
            }
        }
        return 0;
    }
}