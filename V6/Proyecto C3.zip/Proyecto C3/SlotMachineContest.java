import java.util.ArrayList;
import java.util.List;
/**
* Solucion para el problema de SlotMachine
* @author (Santiago Murillo)
*/

// Invariante: De la parte de de solve

public class SlotMachineContest {
    private static final int MAX_ACTIONS = 10000;
    public static SlotMachine currentMachine;
    /**
     * Funcion que decuelve la serie de pasos para el jackpot
     * @param n (int) numero de ruedas
     * 
     */
    //Invariante paso 1: Siempre se deja todas las ruedas mostrando símbolos distintos.
    //Invariante paso 2: Dado que cada uno de los simbolos es diferente, puedo encontrar el patron el cual
    //represente una fila donde cada rueda tiene un posicion especifica con respecto a otra.Ese patro se refiere a que puedo saber si dos ruedas 
    //tienen simbolos seguidos si cuando muevo una rueda una posicion haci el frente y la otra hacia atras obtengo que los distintios simbolos son los maximos
    //los cuales se indican con k ==n, guardando esa referencia puedo empezar a armar mi patron circular donde cada rueda tengo un predecesor y sucesor. 
    //Fue impleementada con ayuda de Claude
    //Invariante paso 3: Dada esta fila, desciframos los movimientos necesarios para rodar gradualmente cada rueda tomando un punto de referencia.
    //Fue implementada con ayuda de Claude,
    public static int[][] solve(int n) {
        if (currentMachine == null) {
            currentMachine = new SlotMachine(n);
        }
    
        List<int[]> moves = new ArrayList<>();
        int totalActions = 0;
        int k = currentMachine.distinctSymbols();
        if (k == 1) {
            return listToArray(moves);
        }
    
        // --- FASE 1:  ---
        for (int wheel = 2; wheel <= n && totalActions < MAX_ACTIONS; wheel++) {
            int bestK = k;
            int bestPos = 0;
    
            for (int pos = 1; pos < n && totalActions < MAX_ACTIONS; pos++) {
                currentMachine.spin(wheel, 1);
                totalActions++;
                k = currentMachine.distinctSymbols();
                moves.add(new int[]{wheel, 1});
    
                if (k == 1) {
                    return listToArray(moves);
                }
    
                if (k > bestK) {
                    bestK = k;
                    bestPos = pos;
                }
            }
    
            int stepsToBest = (bestPos + 1) % n;
            if (stepsToBest > 0 && totalActions < MAX_ACTIONS) {
                currentMachine.spin(wheel, stepsToBest);
                totalActions++;
                k = currentMachine.distinctSymbols();
                moves.add(new int[]{wheel, stepsToBest});
            }
        }
    
        // --- FASE 2 ---
        int[] next = new int[n + 1];
        boolean[] hasnext = new boolean[n + 1];
    
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                if (i == j) continue;
    
                currentMachine.spin(i, 1);
                totalActions++;
                moves.add(new int[]{i, 1});
    
                currentMachine.spin(j, -1);
                totalActions++;
                moves.add(new int[]{j, -1});
    
                k = currentMachine.distinctSymbols();
    
                if (k == 1) {
                    return listToArray(moves);
                }
    
                if (k == n) {
                    next[i] = j;
                }
    
                currentMachine.spin(i, -1);
                totalActions++;
                moves.add(new int[]{i, -1});
    
                currentMachine.spin(j, 1);
                totalActions++;
                moves.add(new int[]{j, 1});
    
                if (hasnext[i]) {
                    break;
                }
            }
        }
    
        // --- FASE 3: alinear todas las ruedas ---
        int[] jumpsReference = new int[n + 1];
        int actual = 1;
        int jumps = 0;
    
        for (int contador = 0; contador < n; contador++) {
            jumpsReference[actual] = jumps;
            actual = next[actual];
            jumps++;                     
        }
    
        for (int wheel = 2; wheel <= n; wheel++) {
            currentMachine.spin(wheel, -jumpsReference[wheel]);
            totalActions++;
            moves.add(new int[]{wheel, -jumpsReference[wheel]});
        }
    
        return listToArray(moves);
    }
    
    /**
     * @param moves (List<int[]>) Nos da la lsita de movimientos para el jackpot
     * @return Retorna un arreglo de arreglos de enteros
     */
    private static int[][] listToArray(List<int[]> moves) {
        return moves.toArray(new int[0][]);
    }

    /**
     * @param n (int) Nos da el numero de ruedas y simbolos
     * Muestra la simulación.
     */
    public static void simulate(int n) {
        currentMachine = new SlotMachine(n);
        currentMachine.makeVisible();
        solve(n);

    }
}