import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class SlotMachineContestTest.
 *
 * @author  (Santiago Murillo)
 * @version (22 de septiembre)
 */
public class SlotMachineContestCTest{
    private SlotMachine machine;
    
    /**
     * Constructor por defecto de la calse tests SlotMachineC2Test
     * Se crea la máquina y se pone en modo INVISIBLE para las pruebas de unidad
     */
    @BeforeEach
    public void setUp() {
        machine = new SlotMachine(5);
    }

    /**
     * Liberar recursos depues de cada prueba unitaria
     *
     */
    @AfterEach
    public void tearDown() {
        machine = null;
    }
    
    /**
     * ¿Qué debería hacer? Mi lista de pasos no puede ser nulla
     * ¿Qué no debería hacer? Dar una lsita de pasos nula
     */
    @Test
    public void accordingMurtestSolveNotNull() {
        int n = 4;
        // Asumiendo que se puede verificar el número de giros retornados
        int[][] moves = SlotMachineContest.solve(n);

        assertNotNull(moves);
    }
    
    /**
     * ¿Qué debería hacer? Revisar que en la segunda posicion de los mmovimientos hagamos movimientos que cambien de estado
     * ¿Qué no debería hacer? hacer spins de 0
     */
    @Test
    public void accordingMurtestSolveDontHaceSpin0() {
        int n = 4;
        int[][] moves = SlotMachineContest.solve(n);

        for (int[] move : moves) {
            assertNotEquals(0, move[1]);
        }
    }
}